import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import AthkarScreen from '../src/screens/AthkarScreen';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';

// إنشاء متجر وهمي للاختبار
const mockStore = configureStore([]);

describe('اختبار شاشة الأذكار', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      athkar: {
        categories: [],
        currentCategory: 'morning',
        athkarList: [],
        loading: false,
        error: null
      },
      settings: {
        darkMode: false,
        fontSize: 'medium',
        fontType: 'default'
      }
    });
    
    // محاكاة استدعاء API
    jest.spyOn(global, 'fetch').mockImplementation(() => 
      Promise.resolve({
        json: () => Promise.resolve({
          athkar: [
            {
              id: 1,
              title: 'أذكار الاستيقاظ من النوم',
              text: 'الحمد لله الذي أحيانا بعد ما أماتنا وإليه النشور',
              count: 1,
              category: 'morning',
              reference: 'رواه البخاري'
            },
            {
              id: 2,
              title: 'دعاء لبس الثوب',
              text: 'الحمد لله الذي كساني هذا (الثوب) ورزقنيه من غير حول مني ولا قوة',
              count: 1,
              category: 'morning',
              reference: 'رواه أبو داود والترمذي'
            }
          ]
        })
      })
    );
  });
  
  afterEach(() => {
    global.fetch.mockRestore();
  });
  
  test('يجب أن تعرض شاشة الأذكار بشكل صحيح', async () => {
    const { getByText, getByTestId } = render(
      <Provider store={store}>
        <AthkarScreen />
      </Provider>
    );
    
    // التحقق من وجود عناصر الواجهة الرئيسية
    expect(getByTestId('athkar-list')).toBeTruthy();
    expect(getByTestId('category-selector')).toBeTruthy();
    
    // التحقق من تحميل الأذكار
    await waitFor(() => {
      expect(getByText('أذكار الاستيقاظ من النوم')).toBeTruthy();
      expect(getByText('الحمد لله الذي أحيانا بعد ما أماتنا وإليه النشور')).toBeTruthy();
      expect(getByText('دعاء لبس الثوب')).toBeTruthy();
    });
  });
  
  test('يجب أن يعمل البحث في الأذكار بشكل صحيح', async () => {
    const { getByTestId, getByText, queryByText } = render(
      <Provider store={store}>
        <AthkarScreen />
      </Provider>
    );
    
    // انتظار تحميل الأذكار
    await waitFor(() => {
      expect(getByText('أذكار الاستيقاظ من النوم')).toBeTruthy();
    });
    
    // محاكاة البحث
    fireEvent.changeText(getByTestId('search-input'), 'لبس');
    
    // التحقق من نتائج البحث
    await waitFor(() => {
      expect(queryByText('أذكار الاستيقاظ من النوم')).toBeNull();
      expect(getByText('دعاء لبس الثوب')).toBeTruthy();
    });
  });
  
  test('يجب أن يعمل تغيير فئة الأذكار بشكل صحيح', async () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <AthkarScreen />
      </Provider>
    );
    
    // محاكاة النقر على فئة أذكار المساء
    fireEvent.press(getByTestId('category-evening'));
    
    // التحقق من تحديث المتجر بالفئة الجديدة
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'athkar/setCurrentCategory',
        payload: 'evening'
      })
    );
  });
  
  test('يجب أن يعمل عداد الأذكار بشكل صحيح', async () => {
    const { getByTestId, getAllByTestId } = render(
      <Provider store={store}>
        <AthkarScreen />
      </Provider>
    );
    
    // انتظار تحميل الأذكار
    await waitFor(() => {
      expect(getAllByTestId('athkar-counter')).toHaveLength(2);
    });
    
    // محاكاة النقر على زر العداد
    const counter = getAllByTestId('athkar-counter')[0];
    fireEvent.press(counter);
    
    // التحقق من زيادة العداد
    expect(counter.props.count).toBe(1);
  });
});
