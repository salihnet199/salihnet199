import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import AudioScreen from '../src/screens/AudioScreen';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';

// إنشاء متجر وهمي للاختبار
const mockStore = configureStore([]);

describe('اختبار شاشة التلاوات الصوتية', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      audio: {
        reciters: [
          { id: 1, name: 'عبد الباسط عبد الصمد', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
          { id: 2, name: 'محمود خليل الحصري', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' }
        ],
        surahs: [
          { id: 1, name: 'الفاتحة', ayahs: 7, translation: 'The Opening' },
          { id: 2, name: 'البقرة', ayahs: 286, translation: 'The Cow' }
        ],
        selectedReciter: { id: 1, name: 'عبد الباسط عبد الصمد', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
        selectedSurah: null,
        currentAudio: null,
        loading: false,
        error: null
      },
      settings: {
        darkMode: false,
        fontSize: 'medium',
        fontType: 'default'
      }
    });
    
    // محاكاة استدعاء API
    jest.spyOn(global, 'fetch').mockImplementation(() => 
      Promise.resolve({
        json: () => Promise.resolve({
          reciters: [
            { id: 1, name: 'عبد الباسط عبد الصمد', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
            { id: 2, name: 'محمود خليل الحصري', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' }
          ],
          surahs: [
            { id: 1, name: 'الفاتحة', ayahs: 7, translation: 'The Opening' },
            { id: 2, name: 'البقرة', ayahs: 286, translation: 'The Cow' }
          ]
        })
      })
    );
  });
  
  afterEach(() => {
    global.fetch.mockRestore();
  });
  
  test('يجب أن تعرض شاشة التلاوات الصوتية بشكل صحيح', async () => {
    const { getByText, getByTestId } = render(
      <Provider store={store}>
        <AudioScreen />
      </Provider>
    );
    
    // التحقق من وجود عناصر الواجهة الرئيسية
    expect(getByTestId('audio-library')).toBeTruthy();
    expect(getByTestId('reciters-list')).toBeTruthy();
    expect(getByTestId('surahs-list')).toBeTruthy();
    
    // التحقق من عرض القراء
    expect(getByText('عبد الباسط عبد الصمد')).toBeTruthy();
    expect(getByText('محمود خليل الحصري')).toBeTruthy();
    
    // التحقق من عرض السور
    expect(getByText('الفاتحة')).toBeTruthy();
    expect(getByText('البقرة')).toBeTruthy();
  });
  
  test('يجب أن يعمل اختيار القارئ بشكل صحيح', async () => {
    const { getAllByTestId } = render(
      <Provider store={store}>
        <AudioScreen />
      </Provider>
    );
    
    // محاكاة النقر على قارئ آخر
    const reciterItems = getAllByTestId('reciter-item');
    fireEvent.press(reciterItems[1]); // محمود خليل الحصري
    
    // التحقق من تحديث المتجر بالقارئ الجديد
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'audio/setSelectedReciter',
        payload: { id: 2, name: 'محمود خليل الحصري', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' }
      })
    );
  });
  
  test('يجب أن يعمل اختيار السورة بشكل صحيح', async () => {
    const { getAllByTestId } = render(
      <Provider store={store}>
        <AudioScreen />
      </Provider>
    );
    
    // محاكاة النقر على سورة
    const surahItems = getAllByTestId('surah-item');
    fireEvent.press(surahItems[0]); // الفاتحة
    
    // التحقق من تحديث المتجر بالسورة الجديدة
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'audio/setSelectedSurah',
        payload: { id: 1, name: 'الفاتحة', ayahs: 7, translation: 'The Opening' }
      })
    );
  });
  
  test('يجب أن يعمل البحث عن القراء بشكل صحيح', async () => {
    const { getByTestId, getByText, queryByText } = render(
      <Provider store={store}>
        <AudioScreen />
      </Provider>
    );
    
    // محاكاة البحث
    fireEvent.changeText(getByTestId('search-input'), 'الحصري');
    
    // التحقق من نتائج البحث
    await waitFor(() => {
      expect(queryByText('عبد الباسط عبد الصمد')).toBeNull();
      expect(getByText('محمود خليل الحصري')).toBeTruthy();
    });
  });
  
  test('يجب أن يعمل مشغل الصوت بشكل صحيح عند اختيار سورة', async () => {
    const { getAllByTestId, getByTestId } = render(
      <Provider store={store}>
        <AudioScreen />
      </Provider>
    );
    
    // محاكاة النقر على سورة
    const surahItems = getAllByTestId('surah-item');
    fireEvent.press(surahItems[0]); // الفاتحة
    
    // التحقق من ظهور مشغل الصوت
    await waitFor(() => {
      expect(getByTestId('audio-player')).toBeTruthy();
    });
    
    // محاكاة النقر على زر التشغيل
    fireEvent.press(getByTestId('play-button'));
    
    // التحقق من تحديث المتجر بحالة التشغيل
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'audio/setPlaybackStatus',
        payload: 'playing'
      })
    );
  });
});
