import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import TafseerScreen from '../src/screens/TafseerScreen';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';

// إنشاء متجر وهمي للاختبار
const mockStore = configureStore([]);

describe('اختبار شاشة التفسير', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      tafseer: {
        tafseerList: [
          { id: 1, name: 'تفسير ابن كثير', author: 'ابن كثير', language: 'ar' },
          { id: 2, name: 'تفسير السعدي', author: 'عبد الرحمن السعدي', language: 'ar' }
        ],
        selectedTafseer: { id: 1, name: 'تفسير ابن كثير', author: 'ابن كثير', language: 'ar' },
        currentSurah: 1,
        currentAyah: 1,
        tafseerContent: '',
        loading: false,
        error: null
      },
      quran: {
        currentAyah: {
          surah_name: 'الفاتحة',
          surah_number: 1,
          number: 1,
          text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
          translation: 'In the name of Allah, the Entirely Merciful, the Especially Merciful'
        }
      },
      settings: {
        darkMode: false,
        fontSize: 'medium',
        fontType: 'default'
      }
    });
    
    // محاكاة استدعاء API
    jest.spyOn(global, 'fetch').mockImplementation(() => 
      Promise.resolve({
        json: () => Promise.resolve({
          tafsir: {
            text: 'قال ابن كثير في تفسير "بسم الله الرحمن الرحيم": البسملة آية من كتاب الله تعالى، وهي جزء من آيات سورة النمل، وهي بعض آية من الفاتحة على أحد القولين، وهي آية مستقلة في أول كل سورة عند من يقول بذلك من العلماء.'
          }
        })
      })
    );
  });
  
  afterEach(() => {
    global.fetch.mockRestore();
  });
  
  test('يجب أن تعرض شاشة التفسير بشكل صحيح', async () => {
    const { getByText, getByTestId } = render(
      <Provider store={store}>
        <TafseerScreen />
      </Provider>
    );
    
    // التحقق من وجود عناصر الواجهة الرئيسية
    expect(getByTestId('tafseer-view')).toBeTruthy();
    expect(getByTestId('tafseer-selector')).toBeTruthy();
    
    // التحقق من عرض الآية
    expect(getByText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')).toBeTruthy();
    
    // التحقق من تحميل التفسير
    await waitFor(() => {
      expect(getByText(/قال ابن كثير في تفسير/)).toBeTruthy();
    });
  });
  
  test('يجب أن يعمل تغيير التفسير بشكل صحيح', async () => {
    const { getByTestId, getAllByTestId } = render(
      <Provider store={store}>
        <TafseerScreen />
      </Provider>
    );
    
    // محاكاة النقر على تفسير آخر
    const tafseerButtons = getAllByTestId('tafseer-button');
    fireEvent.press(tafseerButtons[1]); // تفسير السعدي
    
    // التحقق من تحديث المتجر بالتفسير الجديد
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'tafseer/setSelectedTafseer',
        payload: { id: 2, name: 'تفسير السعدي', author: 'عبد الرحمن السعدي', language: 'ar' }
      })
    );
  });
  
  test('يجب أن تعمل أزرار التنقل بين الآيات بشكل صحيح', async () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <TafseerScreen />
      </Provider>
    );
    
    // محاكاة النقر على زر الآية التالية
    fireEvent.press(getByTestId('next-ayah-button'));
    
    // التحقق من تحديث المتجر بالآية الجديدة
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'tafseer/setCurrentAyah',
        payload: 2
      })
    );
    
    // محاكاة النقر على زر الآية السابقة
    fireEvent.press(getByTestId('prev-ayah-button'));
    
    // التحقق من تحديث المتجر بالآية الجديدة
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'tafseer/setCurrentAyah',
        payload: 1
      })
    );
  });
});
