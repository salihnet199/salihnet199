import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import QuranScreen from '../src/screens/QuranScreen';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';

// إنشاء متجر وهمي للاختبار
const mockStore = configureStore([]);

describe('اختبار شاشة القرآن الكريم', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      quran: {
        currentPage: 1,
        surahs: [],
        loading: false,
        error: null
      },
      settings: {
        darkMode: false,
        fontSize: 'medium',
        fontType: 'default'
      }
    });
    
    // محاكاة استدعاء API
    jest.spyOn(global, 'fetch').mockImplementation(() => 
      Promise.resolve({
        json: () => Promise.resolve({
          verses: [
            { id: 1, text_uthmani: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', verse_key: '1:1' },
            { id: 2, text_uthmani: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', verse_key: '1:2' }
          ]
        })
      })
    );
  });
  
  afterEach(() => {
    global.fetch.mockRestore();
  });
  
  test('يجب أن تعرض شاشة القرآن بشكل صحيح', async () => {
    const { getByText, getByTestId } = render(
      <Provider store={store}>
        <QuranScreen />
      </Provider>
    );
    
    // التحقق من وجود عناصر الواجهة الرئيسية
    expect(getByTestId('quran-page-view')).toBeTruthy();
    expect(getByTestId('page-controls')).toBeTruthy();
    
    // التحقق من تحميل الآيات
    await waitFor(() => {
      expect(getByText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')).toBeTruthy();
      expect(getByText('الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ')).toBeTruthy();
    });
  });
  
  test('يجب أن تتغير الصفحة عند النقر على أزرار التنقل', async () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <QuranScreen />
      </Provider>
    );
    
    // محاكاة النقر على زر الصفحة التالية
    fireEvent.press(getByTestId('next-page-button'));
    
    // التحقق من تحديث المتجر بالصفحة الجديدة
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'quran/setCurrentPage',
        payload: 2
      })
    );
    
    // محاكاة النقر على زر الصفحة السابقة
    fireEvent.press(getByTestId('prev-page-button'));
    
    // التحقق من تحديث المتجر بالصفحة الجديدة
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'quran/setCurrentPage',
        payload: 1
      })
    );
  });
  
  test('يجب أن تعمل وظيفة التكبير والتصغير بشكل صحيح', async () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <QuranScreen />
      </Provider>
    );
    
    // محاكاة النقر على زر التكبير
    fireEvent.press(getByTestId('zoom-in-button'));
    
    // التحقق من تحديث المتجر بحجم الخط الجديد
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'settings/setFontSize',
        payload: 'large'
      })
    );
    
    // محاكاة النقر على زر التصغير
    fireEvent.press(getByTestId('zoom-out-button'));
    
    // التحقق من تحديث المتجر بحجم الخط الجديد
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'settings/setFontSize',
        payload: 'medium'
      })
    );
  });
});
