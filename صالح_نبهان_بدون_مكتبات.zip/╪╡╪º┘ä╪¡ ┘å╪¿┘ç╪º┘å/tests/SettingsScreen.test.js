import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import SettingsScreen from '../src/screens/SettingsScreen';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';

// إنشاء متجر وهمي للاختبار
const mockStore = configureStore([]);

describe('اختبار شاشة الإعدادات', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      settings: {
        darkMode: false,
        fontSize: 'medium',
        fontType: 'default',
        notificationsEnabled: true,
        morningAthkarTime: '07:00',
        eveningAthkarTime: '17:00'
      }
    });
    
    // محاكاة استدعاء API للتخزين المحلي
    jest.spyOn(global, 'localStorage', 'get').mockImplementation(() => ({
      getItem: jest.fn().mockImplementation((key) => {
        if (key === 'settings') {
          return JSON.stringify({
            darkMode: false,
            fontSize: 'medium',
            fontType: 'default',
            notificationsEnabled: true,
            morningAthkarTime: '07:00',
            eveningAthkarTime: '17:00'
          });
        }
        return null;
      }),
      setItem: jest.fn()
    }));
  });
  
  afterEach(() => {
    jest.restoreAllMocks();
  });
  
  test('يجب أن تعرض شاشة الإعدادات بشكل صحيح', async () => {
    const { getByText, getByTestId } = render(
      <Provider store={store}>
        <SettingsScreen />
      </Provider>
    );
    
    // التحقق من وجود عناصر الواجهة الرئيسية
    expect(getByText('الإعدادات')).toBeTruthy();
    expect(getByTestId('dark-mode-switch')).toBeTruthy();
    expect(getByTestId('font-size-selector')).toBeTruthy();
    expect(getByTestId('font-type-selector')).toBeTruthy();
    expect(getByTestId('notifications-switch')).toBeTruthy();
    expect(getByText('حفظ الإعدادات')).toBeTruthy();
    expect(getByText('إعادة ضبط')).toBeTruthy();
  });
  
  test('يجب أن يعمل تبديل الوضع الليلي بشكل صحيح', async () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <SettingsScreen />
      </Provider>
    );
    
    // محاكاة النقر على مفتاح الوضع الليلي
    fireEvent(getByTestId('dark-mode-switch'), 'valueChange', true);
    
    // التحقق من تحديث حالة المكون
    expect(getByTestId('dark-mode-switch').props.value).toBe(true);
  });
  
  test('يجب أن يعمل اختيار حجم الخط بشكل صحيح', async () => {
    const { getByTestId, getAllByTestId } = render(
      <Provider store={store}>
        <SettingsScreen />
      </Provider>
    );
    
    // محاكاة النقر على حجم خط كبير
    const fontSizeOptions = getAllByTestId('font-size-option');
    fireEvent.press(fontSizeOptions[2]); // كبير
    
    // التحقق من تحديث حالة المكون
    expect(fontSizeOptions[2].props.style).toContainEqual(
      expect.objectContaining({
        backgroundColor: expect.any(String) // لون الخلفية يتغير عند الاختيار
      })
    );
  });
  
  test('يجب أن يعمل اختيار نوع الخط بشكل صحيح', async () => {
    const { getAllByTestId } = render(
      <Provider store={store}>
        <SettingsScreen />
      </Provider>
    );
    
    // محاكاة النقر على نوع خط عثماني
    const fontTypeOptions = getAllByTestId('font-type-option');
    fireEvent.press(fontTypeOptions[1]); // عثماني
    
    // التحقق من تحديث حالة المكون
    expect(fontTypeOptions[1].props.style).toContainEqual(
      expect.objectContaining({
        backgroundColor: expect.any(String) // لون الخلفية يتغير عند الاختيار
      })
    );
  });
  
  test('يجب أن يعمل تبديل الإشعارات بشكل صحيح', async () => {
    const { getByTestId } = render(
      <Provider store={store}>
        <SettingsScreen />
      </Provider>
    );
    
    // محاكاة النقر على مفتاح الإشعارات
    fireEvent(getByTestId('notifications-switch'), 'valueChange', false);
    
    // التحقق من تحديث حالة المكون
    expect(getByTestId('notifications-switch').props.value).toBe(false);
  });
  
  test('يجب أن يعمل زر حفظ الإعدادات بشكل صحيح', async () => {
    const { getByTestId, getByText } = render(
      <Provider store={store}>
        <SettingsScreen />
      </Provider>
    );
    
    // محاكاة تغيير بعض الإعدادات
    fireEvent(getByTestId('dark-mode-switch'), 'valueChange', true);
    
    // محاكاة النقر على زر الحفظ
    fireEvent.press(getByText('حفظ الإعدادات'));
    
    // التحقق من تحديث المتجر بالإعدادات الجديدة
    expect(store.getActions()).toContainEqual(
      expect.objectContaining({
        type: 'settings/updateSettings',
        payload: expect.objectContaining({
          darkMode: true
        })
      })
    );
    
    // التحقق من حفظ الإعدادات في التخزين المحلي
    expect(global.localStorage.setItem).toHaveBeenCalledWith(
      'settings',
      expect.any(String)
    );
  });
  
  test('يجب أن يعمل زر إعادة ضبط الإعدادات بشكل صحيح', async () => {
    const { getByText } = render(
      <Provider store={store}>
        <SettingsScreen />
      </Provider>
    );
    
    // محاكاة النقر على زر إعادة الضبط
    fireEvent.press(getByText('إعادة ضبط'));
    
    // محاكاة تأكيد إعادة الضبط
    fireEvent.press(getByText('إعادة ضبط', { selector: 'button' }));
    
    // التحقق من تحديث المتجر بالإعدادات الافتراضية
    await waitFor(() => {
      expect(store.getActions()).toContainEqual(
        expect.objectContaining({
          type: 'settings/updateSettings',
          payload: expect.objectContaining({
            darkMode: false,
            fontSize: 'medium',
            fontType: 'default',
            notificationsEnabled: true
          })
        })
      );
    });
  });
});
