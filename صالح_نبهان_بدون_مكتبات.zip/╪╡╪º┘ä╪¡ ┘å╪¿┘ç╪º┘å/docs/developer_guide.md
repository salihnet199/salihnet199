# دليل المطور - تطبيق إسلامي متكامل

## مقدمة

هذا الدليل مخصص للمطورين الذين يرغبون في فهم بنية التطبيق الإسلامي المتكامل وكيفية تطويره وتوسيعه. يوفر هذا الدليل نظرة عامة على هيكل المشروع، والتقنيات المستخدمة، وكيفية إعداد بيئة التطوير، وإرشادات للمساهمة في المشروع.

## التقنيات المستخدمة

- **React Native**: إطار عمل لتطوير تطبيقات الهواتف المحمولة متعددة المنصات
- **Expo**: منصة لتسهيل تطوير تطبيقات React Native
- **Redux**: مكتبة لإدارة حالة التطبيق
- **Axios**: مكتبة للتعامل مع طلبات HTTP
- **React Navigation**: مكتبة للتنقل بين الشاشات
- **React Native Vector Icons**: مكتبة للأيقونات
- **React Native Sound**: مكتبة للتعامل مع الصوت
- **React Native Track Player**: مكتبة لتشغيل الملفات الصوتية

## هيكل المشروع

```
islamic_app/
├── src/
│   ├── api/                  # واجهات برمجة التطبيقات
│   │   ├── index.js          # نقطة دخول لجميع واجهات برمجة التطبيقات
│   │   ├── quranAPI.js       # واجهة برمجة تطبيقات القرآن الكريم
│   │   ├── athkarAPI.js      # واجهة برمجة تطبيقات الأذكار
│   │   ├── audioAPI.js       # واجهة برمجة تطبيقات التلاوات الصوتية
│   │   └── searchAPI.js      # واجهة برمجة تطبيقات البحث
│   ├── components/           # المكونات المشتركة
│   │   ├── Card.js           # مكون البطاقة
│   │   ├── IconButton.js     # مكون زر الأيقونة
│   │   ├── LoadingIndicator.js # مكون مؤشر التحميل
│   │   ├── ErrorDisplay.js   # مكون عرض الأخطاء
│   │   ├── SearchBar.js      # مكون شريط البحث
│   │   ├── AthkarCounter.js  # مكون عداد الأذكار
│   │   ├── AyahRenderer.js   # مكون عرض الآيات
│   │   ├── AudioPlayer.js    # مكون مشغل الصوت
│   │   ├── QuranPageView.js  # مكون عرض صفحة المصحف
│   │   ├── HomeScreenGrid.js # مكون شبكة الشاشة الرئيسية
│   │   ├── AthkarList.js     # مكون قائمة الأذكار
│   │   ├── TafseerView.js    # مكون عرض التفسير
│   │   └── AudioLibrary.js   # مكون مكتبة التلاوات الصوتية
│   ├── screens/              # شاشات التطبيق
│   │   ├── HomeScreen.js     # الشاشة الرئيسية
│   │   ├── QuranScreen.js    # شاشة القرآن الكريم
│   │   ├── AthkarScreen.js   # شاشة الأذكار
│   │   ├── TafseerScreen.js  # شاشة التفسير
│   │   ├── AudioScreen.js    # شاشة التلاوات الصوتية
│   │   └── SettingsScreen.js # شاشة الإعدادات
│   ├── redux/                # إدارة حالة التطبيق
│   │   ├── store.js          # متجر Redux
│   │   └── slices/           # شرائح Redux
│   │       ├── quranSlice.js # شريحة القرآن الكريم
│   │       ├── athkarSlice.js # شريحة الأذكار
│   │       ├── tafseerSlice.js # شريحة التفسير
│   │       ├── audioSlice.js # شريحة التلاوات الصوتية
│   │       └── settingsSlice.js # شريحة الإعدادات
│   ├── services/             # خدمات التطبيق
│   │   ├── QuranService.js   # خدمة القرآن الكريم
│   │   ├── AthkarService.js  # خدمة الأذكار
│   │   ├── TafseerService.js # خدمة التفسير
│   │   ├── AudioService.js   # خدمة التلاوات الصوتية
│   │   ├── StorageService.js # خدمة التخزين المحلي
│   │   └── NotificationService.js # خدمة الإشعارات
│   ├── styles/               # أنماط التطبيق
│   │   ├── colors.js         # ألوان التطبيق
│   │   ├── typography.js     # خطوط التطبيق
│   │   ├── spacing.js        # تباعد التطبيق
│   │   ├── shadows.js        # ظلال التطبيق
│   │   └── common.js         # أنماط مشتركة
│   ├── utils/                # أدوات مساعدة
│   ├── hooks/                # خطافات React المخصصة
│   ├── context/              # سياقات React
│   └── navigation/           # تكوين التنقل
├── assets/                   # الموارد الثابتة
├── tests/                    # اختبارات التطبيق
├── docs/                     # وثائق التطبيق
├── App.js                    # نقطة دخول التطبيق
├── app.json                  # تكوين Expo
└── package.json              # تبعيات المشروع
```

## إعداد بيئة التطوير

### المتطلبات الأساسية

- Node.js (الإصدار 14 أو أحدث)
- npm (الإصدار 6 أو أحدث)
- Expo CLI

### خطوات الإعداد

1. استنساخ المستودع:
   ```bash
   git clone https://github.com/username/islamic_app.git
   cd islamic_app
   ```

2. تثبيت التبعيات:
   ```bash
   npm install
   ```

3. تشغيل التطبيق في وضع التطوير:
   ```bash
   npm start
   ```

4. اختبار التطبيق:
   ```bash
   npm test
   ```

## دليل المكونات الرئيسية

### واجهات برمجة التطبيقات (API)

#### quranAPI.js

يوفر هذا الملف دوالاً للتفاعل مع واجهة برمجة تطبيقات القرآن الكريم:

```javascript
// الحصول على قائمة السور
const surahs = await quranAPI.getSurahs();

// الحصول على صفحة محددة من المصحف
const page = await quranAPI.getQuranPage(1);

// الحصول على تفسير آية محددة
const tafsir = await quranAPI.getVerseTafsir(1, '1:1');
```

#### athkarAPI.js

يوفر هذا الملف دوالاً للتفاعل مع واجهة برمجة تطبيقات الأذكار:

```javascript
// الحصول على أذكار الصباح
const morningAthkar = await athkarAPI.getMorningAthkar();

// البحث في الأذكار
const searchResults = await athkarAPI.searchAthkar('الصلاة');
```

#### audioAPI.js

يوفر هذا الملف دوالاً للتفاعل مع واجهة برمجة تطبيقات التلاوات الصوتية:

```javascript
// الحصول على قائمة القراء
const reciters = await audioAPI.getReciters();

// الحصول على تلاوة سورة محددة لقارئ محدد
const recitation = await audioAPI.getSurahRecitation(1, 1);
```

#### searchAPI.js

يوفر هذا الملف دوالاً للبحث في القرآن الكريم:

```javascript
// البحث في القرآن الكريم
const searchResults = await searchAPI.searchQuran('الرحمن');

// البحث المتقدم في القرآن الكريم
const advancedResults = await searchAPI.advancedSearch({
  query: 'الرحمن',
  surahs: [1, 2, 3]
});
```

### Redux Slices

#### quranSlice.js

يدير هذا الملف حالة القرآن الكريم في التطبيق:

```javascript
// تحديث الصفحة الحالية
dispatch(setCurrentPage(1));

// تحميل السور
dispatch(fetchSurahs());
```

#### athkarSlice.js

يدير هذا الملف حالة الأذكار في التطبيق:

```javascript
// تحديث فئة الأذكار الحالية
dispatch(setCurrentCategory('morning'));

// تحميل الأذكار
dispatch(fetchAthkar('morning'));
```

#### settingsSlice.js

يدير هذا الملف إعدادات التطبيق:

```javascript
// تحديث الوضع الليلي
dispatch(setDarkMode(true));

// تحديث حجم الخط
dispatch(setFontSize('large'));
```

## إرشادات المساهمة

### إضافة ميزة جديدة

1. إنشاء فرع جديد:
   ```bash
   git checkout -b feature/new-feature
   ```

2. تنفيذ الميزة الجديدة.

3. إضافة اختبارات للميزة الجديدة.

4. تقديم طلب سحب (Pull Request).

### إصلاح الأخطاء

1. إنشاء فرع جديد:
   ```bash
   git checkout -b fix/bug-description
   ```

2. إصلاح الخطأ.

3. التأكد من أن جميع الاختبارات تمر.

4. تقديم طلب سحب (Pull Request).

### معايير الكود

- استخدام ESLint للتحقق من جودة الكود.
- اتباع نمط التسمية camelCase للمتغيرات والدوال.
- كتابة تعليقات توثيقية لجميع الدوال والمكونات.
- استخدام التنسيق المناسب للكود.

## تحسين الأداء

### نصائح لتحسين أداء التطبيق

1. استخدام `React.memo` لتجنب إعادة تقديم المكونات غير الضرورية.
2. استخدام `useMemo` و `useCallback` لتخزين القيم والدوال.
3. تجنب استخدام `inline styles` واستخدام `StyleSheet.create` بدلاً من ذلك.
4. استخدام `FlatList` بدلاً من `ScrollView` للقوائم الطويلة.
5. تحسين استخدام الصور باستخدام `Image.prefetch`.
6. استخدام التخزين المؤقت للبيانات المستردة من واجهات برمجة التطبيقات.

## الاختبارات

### اختبارات الوحدة

استخدام Jest و React Testing Library لاختبار المكونات والدوال:

```javascript
// اختبار مكون
test('يجب أن يعرض مكون القرآن بشكل صحيح', () => {
  const { getByText } = render(<QuranComponent />);
  expect(getByText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')).toBeTruthy();
});

// اختبار دالة
test('يجب أن تعيد دالة البحث نتائج صحيحة', () => {
  const results = searchFunction('الرحمن');
  expect(results.length).toBeGreaterThan(0);
});
```

### اختبارات التكامل

اختبار تفاعل المكونات مع بعضها البعض:

```javascript
test('يجب أن يعمل تغيير الصفحة بشكل صحيح', () => {
  const { getByTestId } = render(<QuranScreen />);
  fireEvent.press(getByTestId('next-page-button'));
  expect(store.getActions()).toContainEqual(
    expect.objectContaining({
      type: 'quran/setCurrentPage',
      payload: 2
    })
  );
});
```

## النشر

### نشر التطبيق على متجر Google Play

1. إنشاء ملف APK:
   ```bash
   expo build:android
   ```

2. اتباع إرشادات Google Play Console لنشر التطبيق.

### نشر التطبيق على متجر App Store

1. إنشاء ملف IPA:
   ```bash
   expo build:ios
   ```

2. اتباع إرشادات App Store Connect لنشر التطبيق.

## الموارد

- [وثائق React Native](https://reactnative.dev/docs/getting-started)
- [وثائق Expo](https://docs.expo.io/)
- [وثائق Redux](https://redux.js.org/)
- [وثائق React Navigation](https://reactnavigation.org/docs/getting-started)
- [وثائق واجهة برمجة تطبيقات القرآن الكريم](https://quran.api-docs.io/)

## الدعم

إذا كان لديك أي أسئلة أو استفسارات، يرجى التواصل مع فريق التطوير عبر:

- البريد الإلكتروني: dev@islamicapp.com
- قناة Slack: #islamic-app-dev

نتطلع إلى مساهمتك في تطوير هذا التطبيق الإسلامي المتكامل!
