import { configureStore } from '@reduxjs/toolkit';
import quranReducer from './slices/quranSlice';
import athkarReducer from './slices/athkarSlice';
import tafseerReducer from './slices/tafseerSlice';
import settingsReducer from './slices/settingsSlice';
import audioReducer from './slices/audioSlice';

export const store = configureStore({
  reducer: {
    quran: quranReducer,
    athkar: athkarReducer,
    tafseer: tafseerReducer,
    settings: settingsReducer,
    audio: audioReducer,
  },
});
