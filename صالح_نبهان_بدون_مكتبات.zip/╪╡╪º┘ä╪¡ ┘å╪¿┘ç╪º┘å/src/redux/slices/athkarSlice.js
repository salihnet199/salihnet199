import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// استدعاء واجهة برمجة التطبيقات للحصول على بيانات الأذكار
export const fetchAthkarData = createAsyncThunk(
  'athkar/fetchAthkarData',
  async (category, { rejectWithValue }) => {
    try {
      // سيتم استبدال هذا برابط API حقيقي
      const response = await axios.get(`https://api.hisnmuslim.com/api/v1/athkar/${category}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const initialState = {
  morningAthkar: [],
  eveningAthkar: [],
  otherAthkar: [],
  categories: [],
  currentCategory: null,
  loading: false,
  error: null,
  counter: {},
};

const athkarSlice = createSlice({
  name: 'athkar',
  initialState,
  reducers: {
    setCurrentCategory: (state, action) => {
      state.currentCategory = action.payload;
    },
    incrementCounter: (state, action) => {
      const { id, total } = action.payload;
      if (!state.counter[id]) {
        state.counter[id] = 0;
      }
      if (state.counter[id] < total) {
        state.counter[id] += 1;
      }
    },
    resetCounter: (state, action) => {
      state.counter[action.payload] = 0;
    },
    resetAllCounters: (state) => {
      state.counter = {};
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAthkarData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAthkarData.fulfilled, (state, action) => {
        state.loading = false;
        const { category, data } = action.payload;
        
        if (category === 'morning') {
          state.morningAthkar = data;
        } else if (category === 'evening') {
          state.eveningAthkar = data;
        } else {
          state.otherAthkar = data;
        }
      })
      .addCase(fetchAthkarData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { setCurrentCategory, incrementCounter, resetCounter, resetAllCounters } = athkarSlice.actions;

export default athkarSlice.reducer;
