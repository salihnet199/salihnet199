import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  darkMode: false,
  fontSize: 'medium', // small, medium, large
  fontType: 'default', // default, uthmani, etc.
  notifications: {
    athkarMorning: true,
    athkarEvening: true,
    dailyVerse: true,
  },
  language: 'ar',
};

const settingsSlice = createSlice({
  name: 'settings',
  initialState,
  reducers: {
    toggleDarkMode: (state) => {
      state.darkMode = !state.darkMode;
    },
    setFontSize: (state, action) => {
      state.fontSize = action.payload;
    },
    setFontType: (state, action) => {
      state.fontType = action.payload;
    },
    toggleNotification: (state, action) => {
      const notificationType = action.payload;
      state.notifications[notificationType] = !state.notifications[notificationType];
    },
    setLanguage: (state, action) => {
      state.language = action.payload;
    },
  },
});

export const { 
  toggleDarkMode, 
  setFontSize, 
  setFontType, 
  toggleNotification,
  setLanguage
} = settingsSlice.actions;

export default settingsSlice.reducer;
