import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// استدعاء واجهة برمجة التطبيقات للحصول على بيانات التفسير
export const fetchTafseerData = createAsyncThunk(
  'tafseer/fetchTafseerData',
  async ({ surahNumber, ayahNumber, tafseerID }, { rejectWithValue }) => {
    try {
      // سيتم استبدال هذا برابط API حقيقي
      const response = await axios.get(`https://api.quran.com/api/v4/tafsirs/${tafseerID}/by_ayah/${surahNumber}/${ayahNumber}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const initialState = {
  tafseerList: [
    { id: 1, name: 'تفسير ابن كثير', language: 'ar' },
    { id: 2, name: 'تفسير السعدي', language: 'ar' },
    { id: 3, name: 'تفسير الطبري', language: 'ar' },
    { id: 4, name: 'تفسير القرطبي', language: 'ar' }
  ],
  currentTafseer: 1,
  currentTafseerData: {},
  loading: false,
  error: null,
};

const tafseerSlice = createSlice({
  name: 'tafseer',
  initialState,
  reducers: {
    setCurrentTafseer: (state, action) => {
      state.currentTafseer = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTafseerData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTafseerData.fulfilled, (state, action) => {
        state.loading = false;
        const { surahNumber, ayahNumber } = action.meta.arg;
        const key = `${surahNumber}:${ayahNumber}`;
        state.currentTafseerData[key] = action.payload.tafsir;
      })
      .addCase(fetchTafseerData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { setCurrentTafseer } = tafseerSlice.actions;

export default tafseerSlice.reducer;
