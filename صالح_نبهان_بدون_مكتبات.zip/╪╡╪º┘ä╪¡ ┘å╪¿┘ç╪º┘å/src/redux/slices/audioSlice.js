import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// استدعاء واجهة برمجة التطبيقات للحصول على بيانات التلاوات الصوتية
export const fetchRecitations = createAsyncThunk(
  'audio/fetchRecitations',
  async (_, { rejectWithValue }) => {
    try {
      // سيتم استبدال هذا برابط API حقيقي
      const response = await axios.get('https://api.quran.com/api/v4/resources/recitations');
      return response.data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// استدعاء واجهة برمجة التطبيقات للحصول على تلاوة محددة
export const fetchAudioFile = createAsyncThunk(
  'audio/fetchAudioFile',
  async ({ reciterId, surahNumber, ayahNumber }, { rejectWithValue }) => {
    try {
      // سيتم استبدال هذا برابط API حقيقي
      const response = await axios.get(`https://api.quran.com/api/v4/recitations/${reciterId}/by_ayah/${surahNumber}/${ayahNumber}`);
      return {
        surahNumber,
        ayahNumber,
        audioUrl: response.data.audio_url
      };
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const initialState = {
  recitations: [],
  currentReciter: 1,
  audioFiles: {},
  isPlaying: false,
  currentAudio: null,
  repeatMode: 'none', // none, single, range
  repeatCount: 1,
  loading: false,
  error: null,
};

const audioSlice = createSlice({
  name: 'audio',
  initialState,
  reducers: {
    setCurrentReciter: (state, action) => {
      state.currentReciter = action.payload;
    },
    setIsPlaying: (state, action) => {
      state.isPlaying = action.payload;
    },
    setCurrentAudio: (state, action) => {
      state.currentAudio = action.payload;
    },
    setRepeatMode: (state, action) => {
      state.repeatMode = action.payload;
    },
    setRepeatCount: (state, action) => {
      state.repeatCount = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchRecitations.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchRecitations.fulfilled, (state, action) => {
        state.loading = false;
        state.recitations = action.payload.recitations;
      })
      .addCase(fetchRecitations.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchAudioFile.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAudioFile.fulfilled, (state, action) => {
        state.loading = false;
        const { surahNumber, ayahNumber, audioUrl } = action.payload;
        const key = `${surahNumber}:${ayahNumber}`;
        state.audioFiles[key] = audioUrl;
      })
      .addCase(fetchAudioFile.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { 
  setCurrentReciter, 
  setIsPlaying, 
  setCurrentAudio, 
  setRepeatMode, 
  setRepeatCount 
} = audioSlice.actions;

export default audioSlice.reducer;
