import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// استدعاء واجهة برمجة التطبيقات للحصول على بيانات القرآن
export const fetchQuranData = createAsyncThunk(
  'quran/fetchQuranData',
  async (_, { rejectWithValue }) => {
    try {
      // سيتم استبدال هذا برابط API حقيقي
      const response = await axios.get('https://api.quran.com/api/v4/chapters');
      return response.data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// استدعاء واجهة برمجة التطبيقات للحصول على صفحة محددة من القرآن
export const fetchQuranPage = createAsyncThunk(
  'quran/fetchQuranPage',
  async (pageNumber, { rejectWithValue }) => {
    try {
      // سيتم استبدال هذا برابط API حقيقي
      const response = await axios.get(`https://api.quran.com/api/v4/quran/verses/uthmani?page_number=${pageNumber}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const initialState = {
  surahs: [],
  currentPage: 1,
  pageContent: [],
  bookmarks: [],
  lastRead: null,
  loading: false,
  error: null,
};

const quranSlice = createSlice({
  name: 'quran',
  initialState,
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    addBookmark: (state, action) => {
      state.bookmarks.push(action.payload);
    },
    removeBookmark: (state, action) => {
      state.bookmarks = state.bookmarks.filter(bookmark => bookmark.id !== action.payload);
    },
    setLastRead: (state, action) => {
      state.lastRead = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchQuranData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchQuranData.fulfilled, (state, action) => {
        state.loading = false;
        state.surahs = action.payload.chapters;
      })
      .addCase(fetchQuranData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchQuranPage.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchQuranPage.fulfilled, (state, action) => {
        state.loading = false;
        state.pageContent = action.payload.verses;
      })
      .addCase(fetchQuranPage.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { setCurrentPage, addBookmark, removeBookmark, setLastRead } = quranSlice.actions;

export default quranSlice.reducer;
