/**
 * تحسينات واجهة المستخدم للتطبيق الإسلامي المتكامل
 * 
 * هذا الملف يحتوي على تحسينات واجهة المستخدم المطبقة على التطبيق
 * لتحسين تجربة المستخدم وجعل التطبيق أكثر جاذبية وسهولة في الاستخدام.
 */

import { StyleSheet } from 'react-native';
import colors from '../styles/colors';
import typography from '../styles/typography';
import spacing from '../styles/spacing';
import shadows from '../styles/shadows';

/**
 * تحسينات عامة لواجهة المستخدم
 */
const uiEnhancements = {
  // تحسينات الوضع الليلي
  darkMode: {
    enabled: true,
    autoDetect: true, // اكتشاف إعدادات النظام تلقائياً
    transitionDuration: 300, // مدة الانتقال بالميلي ثانية
  },
  
  // تحسينات إمكانية الوصول
  accessibility: {
    largeTextSupport: true, // دعم النص الكبير
    screenReaderSupport: true, // دعم قارئ الشاشة
    highContrastMode: true, // وضع التباين العالي
    reduceMotion: true, // تقليل الحركة
  },
  
  // تحسينات التفاعل
  interaction: {
    hapticFeedback: true, // ردود الفعل اللمسية
    animatedTransitions: true, // انتقالات متحركة
    gestureNavigation: true, // التنقل بالإيماءات
  },
  
  // تحسينات التخصيص
  customization: {
    fontSelection: true, // اختيار الخط
    colorThemes: true, // سمات الألوان
    layoutOptions: true, // خيارات التخطيط
  },
};

/**
 * إنشاء أنماط محسنة للمكونات
 * @param {string} componentType - نوع المكون
 * @param {Object} options - خيارات التخصيص
 * @returns {Object} أنماط محسنة للمكون
 */
export const createEnhancedStyles = (componentType, options = {}) => {
  const isDarkMode = options.darkMode || false;
  const baseStyles = {};
  
  // أنماط أساسية مشتركة
  const commonStyles = {
    container: {
      padding: spacing.medium,
      backgroundColor: isDarkMode ? colors.darkBackground : colors.lightBackground,
      borderRadius: 8,
      ...shadows.medium,
    },
    text: {
      fontFamily: typography.fontFamily,
      fontSize: typography.fontSize.medium,
      color: isDarkMode ? colors.darkText : colors.lightText,
    },
    title: {
      fontFamily: typography.fontFamily,
      fontSize: typography.fontSize.large,
      fontWeight: 'bold',
      color: isDarkMode ? colors.darkPrimary : colors.primary,
      marginBottom: spacing.small,
    },
    button: {
      backgroundColor: colors.primary,
      padding: spacing.medium,
      borderRadius: 8,
      alignItems: 'center',
      justifyContent: 'center',
      ...shadows.small,
    },
    buttonText: {
      fontFamily: typography.fontFamily,
      fontSize: typography.fontSize.medium,
      fontWeight: 'bold',
      color: colors.white,
    },
  };
  
  // أنماط خاصة بالمكونات
  switch (componentType) {
    case 'card':
      return StyleSheet.create({
        ...commonStyles,
        container: {
          ...commonStyles.container,
          marginVertical: spacing.small,
          elevation: 3,
        },
      });
      
    case 'quranPage':
      return StyleSheet.create({
        ...commonStyles,
        container: {
          ...commonStyles.container,
          padding: spacing.large,
          backgroundColor: isDarkMode ? colors.darkSecondary : colors.lightSecondary,
        },
        ayahText: {
          fontFamily: typography.quranFontFamily,
          fontSize: options.fontSize || typography.fontSize.large,
          color: isDarkMode ? colors.darkText : colors.lightText,
          textAlign: 'center',
          lineHeight: typography.lineHeight.large,
          marginVertical: spacing.small,
        },
        surahTitle: {
          ...commonStyles.title,
          textAlign: 'center',
          marginBottom: spacing.medium,
        },
      });
      
    case 'athkarItem':
      return StyleSheet.create({
        ...commonStyles,
        container: {
          ...commonStyles.container,
          marginVertical: spacing.small,
        },
        athkarText: {
          fontFamily: typography.fontFamily,
          fontSize: options.fontSize || typography.fontSize.medium,
          color: isDarkMode ? colors.darkText : colors.lightText,
          lineHeight: typography.lineHeight.medium,
          marginVertical: spacing.small,
        },
        counterContainer: {
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginTop: spacing.small,
        },
        counterText: {
          fontFamily: typography.fontFamily,
          fontSize: typography.fontSize.small,
          color: isDarkMode ? colors.darkSecondaryText : colors.secondaryText,
        },
      });
      
    case 'tafseerView':
      return StyleSheet.create({
        ...commonStyles,
        container: {
          ...commonStyles.container,
          padding: spacing.large,
        },
        tafseerText: {
          fontFamily: typography.fontFamily,
          fontSize: options.fontSize || typography.fontSize.medium,
          color: isDarkMode ? colors.darkText : colors.lightText,
          lineHeight: typography.lineHeight.medium,
          marginVertical: spacing.small,
          textAlign: 'justify',
        },
        sourceText: {
          fontFamily: typography.fontFamily,
          fontSize: typography.fontSize.small,
          color: isDarkMode ? colors.darkSecondaryText : colors.secondaryText,
          marginTop: spacing.medium,
          textAlign: 'left',
        },
      });
      
    case 'audioPlayer':
      return StyleSheet.create({
        ...commonStyles,
        container: {
          ...commonStyles.container,
          padding: spacing.medium,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        },
        controls: {
          flexDirection: 'row',
          alignItems: 'center',
        },
        playButton: {
          ...commonStyles.button,
          width: 50,
          height: 50,
          borderRadius: 25,
          marginHorizontal: spacing.small,
        },
        progressContainer: {
          flex: 1,
          marginHorizontal: spacing.medium,
        },
        timeText: {
          fontFamily: typography.fontFamily,
          fontSize: typography.fontSize.small,
          color: isDarkMode ? colors.darkSecondaryText : colors.secondaryText,
        },
      });
      
    case 'searchBar':
      return StyleSheet.create({
        ...commonStyles,
        container: {
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: isDarkMode ? colors.darkSecondary : colors.lightSecondary,
          borderRadius: 8,
          padding: spacing.small,
          marginVertical: spacing.medium,
          ...shadows.small,
        },
        input: {
          flex: 1,
          fontFamily: typography.fontFamily,
          fontSize: typography.fontSize.medium,
          color: isDarkMode ? colors.darkText : colors.lightText,
          padding: spacing.small,
          textAlign: 'right',
        },
        icon: {
          marginHorizontal: spacing.small,
          color: isDarkMode ? colors.darkIcon : colors.icon,
        },
      });
      
    default:
      return StyleSheet.create(commonStyles);
  }
};

/**
 * تطبيق تحسينات واجهة المستخدم على المكونات
 * @param {React.Component} Component - المكون المراد تحسينه
 * @param {Object} options - خيارات التحسين
 * @returns {React.Component} المكون المحسن
 */
export const enhanceUI = (Component, options = {}) => {
  // إضافة تحسينات واجهة المستخدم إلى المكون
  return (props) => {
    const enhancedProps = {
      ...props,
      style: createEnhancedStyles(options.componentType || 'default', {
        darkMode: props.darkMode,
        fontSize: props.fontSize,
      }),
      accessibilityLabel: props.accessibilityLabel || options.accessibilityLabel,
      accessibilityHint: props.accessibilityHint || options.accessibilityHint,
    };
    
    return <Component {...enhancedProps} />;
  };
};

/**
 * إضافة دعم الوضع الليلي إلى المكون
 * @param {React.Component} Component - المكون المراد تحسينه
 * @returns {React.Component} المكون مع دعم الوضع الليلي
 */
export const withDarkMode = (Component) => {
  return (props) => {
    // استخدام سياق الوضع الليلي
    const isDarkMode = useContext(ThemeContext).darkMode;
    
    return <Component {...props} darkMode={isDarkMode} />;
  };
};

/**
 * إضافة دعم إمكانية الوصول إلى المكون
 * @param {React.Component} Component - المكون المراد تحسينه
 * @param {Object} options - خيارات إمكانية الوصول
 * @returns {React.Component} المكون مع دعم إمكانية الوصول
 */
export const withAccessibility = (Component, options = {}) => {
  return (props) => {
    const accessibilityProps = {
      accessible: true,
      accessibilityLabel: options.label || props.accessibilityLabel,
      accessibilityHint: options.hint || props.accessibilityHint,
      accessibilityRole: options.role || props.accessibilityRole,
    };
    
    return <Component {...props} {...accessibilityProps} />;
  };
};

export default {
  uiEnhancements,
  createEnhancedStyles,
  enhanceUI,
  withDarkMode,
  withAccessibility,
};
