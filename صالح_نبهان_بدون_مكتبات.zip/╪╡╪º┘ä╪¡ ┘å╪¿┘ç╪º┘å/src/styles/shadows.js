/**
 * ملف أنماط الظلال للتطبيق
 */

import { Platform } from 'react-native';

// ظلال للمنصات المختلفة
const createShadow = (elevation) => {
  if (Platform.OS === 'ios') {
    return {
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: elevation / 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: elevation,
    };
  } else {
    return {
      elevation,
    };
  }
};

// مستويات الظلال
const SHADOW_LEVELS = {
  none: createShadow(0),
  xs: createShadow(1),
  sm: createShadow(2),
  md: createShadow(4),
  lg: createShadow(6),
  xl: createShadow(8),
  xxl: createShadow(12),
};

// ظلال للعناصر المختلفة
const ELEMENT_SHADOWS = {
  card: SHADOW_LEVELS.sm,
  button: SHADOW_LEVELS.sm,
  header: SHADOW_LEVELS.md,
  modal: SHADOW_LEVELS.lg,
  fab: SHADOW_LEVELS.lg,
};

/**
 * الحصول على أنماط الظلال
 * @returns {Object} كائن يحتوي على أنماط الظلال
 */
const getShadows = () => {
  return {
    ...SHADOW_LEVELS,
    elements: ELEMENT_SHADOWS,
  };
};

export {
  SHADOW_LEVELS,
  ELEMENT_SHADOWS,
  getShadows,
  createShadow,
};
