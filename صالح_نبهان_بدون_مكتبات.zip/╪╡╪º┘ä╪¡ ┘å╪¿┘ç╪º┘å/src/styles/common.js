/**
 * ملف الأنماط المشتركة القابلة لإعادة الاستخدام
 */

import { StyleSheet } from 'react-native';
import { getThemeColors } from './colors';
import { getTypography } from './typography';
import { getSpacing } from './spacing';
import { getShadows } from './shadows';

/**
 * إنشاء أنماط مشتركة بناءً على إعدادات الثيم
 * @param {boolean} darkMode - هل الوضع الليلي مفعل
 * @param {string} fontSize - حجم الخط (small, medium, large)
 * @param {string} fontType - نوع الخط (default, uthmani)
 * @returns {Object} كائن يحتوي على الأنماط المشتركة
 */
const createCommonStyles = (darkMode = false, fontSize = 'medium', fontType = 'default') => {
  const colors = getThemeColors(darkMode);
  const typography = getTypography(fontSize, fontType);
  const spacing = getSpacing();
  const shadows = getShadows();

  return StyleSheet.create({
    // أنماط الحاويات
    container: {
      flex: 1,
      backgroundColor: colors.background,
      padding: spacing.screen.horizontal,
    },
    safeArea: {
      flex: 1,
      backgroundColor: colors.background,
    },
    centeredContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: colors.background,
    },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    rowSpaceBetween: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    
    // أنماط البطاقات
    card: {
      backgroundColor: colors.surface,
      borderRadius: spacing.card.borderRadius,
      padding: spacing.card.padding,
      marginVertical: spacing.card.margin,
      ...shadows.elements.card,
    },
    cardHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: spacing.md,
    },
    cardFooter: {
      marginTop: spacing.md,
      borderTopWidth: 1,
      borderTopColor: darkMode ? '#333333' : '#f0f0f0',
      paddingTop: spacing.sm,
    },
    
    // أنماط النصوص
    title: {
      ...typography.h1,
      color: colors.text,
      textAlign: 'center',
      marginVertical: spacing.text.title,
    },
    subtitle: {
      ...typography.h2,
      color: colors.text,
      marginBottom: spacing.md,
    },
    sectionTitle: {
      ...typography.h3,
      color: colors.text,
      marginBottom: spacing.sm,
      marginTop: spacing.md,
    },
    bodyText: {
      ...typography.body,
      color: colors.text,
      marginBottom: spacing.text.paragraph,
    },
    captionText: {
      ...typography.caption,
      color: colors.textSecondary,
    },
    quranText: {
      ...typography.quranText,
      color: colors.text,
    },
    athkarText: {
      ...typography.athkarText,
      color: colors.text,
    },
    
    // أنماط الأزرار
    button: {
      backgroundColor: colors.primary,
      borderRadius: spacing.button.borderRadius,
      padding: spacing.button.padding,
      alignItems: 'center',
      justifyContent: 'center',
      marginVertical: spacing.button.margin,
      ...shadows.elements.button,
    },
    buttonText: {
      ...typography.button,
      color: '#ffffff',
    },
    secondaryButton: {
      backgroundColor: 'transparent',
      borderWidth: 1,
      borderColor: colors.primary,
      borderRadius: spacing.button.borderRadius,
      padding: spacing.button.padding,
      alignItems: 'center',
      justifyContent: 'center',
      marginVertical: spacing.button.margin,
    },
    secondaryButtonText: {
      ...typography.button,
      color: colors.primary,
    },
    
    // أنماط الفواصل
    divider: {
      height: 1,
      backgroundColor: darkMode ? '#333333' : '#e0e0e0',
      marginVertical: spacing.md,
    },
    
    // أنماط الإدخال
    input: {
      backgroundColor: darkMode ? '#333333' : '#f5f5f5',
      borderRadius: spacing.sm,
      padding: spacing.md,
      color: colors.text,
      ...typography.body,
      marginBottom: spacing.md,
    },
    
    // أنماط القوائم
    listItem: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: spacing.md,
      borderBottomWidth: 1,
      borderBottomColor: darkMode ? '#333333' : '#f0f0f0',
    },
    
    // أنماط الشاشات
    screenHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingVertical: spacing.md,
      marginBottom: spacing.md,
      ...shadows.elements.header,
    },
  });
};

export {
  createCommonStyles,
};
