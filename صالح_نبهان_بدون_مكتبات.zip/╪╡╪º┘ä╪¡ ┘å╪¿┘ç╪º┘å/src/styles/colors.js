/**
 * ملف الألوان الأساسية للتطبيق
 */

// الألوان الأساسية
const PRIMARY = '#4CAF50';
const PRIMARY_DARK = '#388E3C';
const PRIMARY_LIGHT = '#A5D6A7';
const ACCENT = '#FFC107';

// ألوان النص
const TEXT_PRIMARY = '#212121';
const TEXT_SECONDARY = '#757575';
const TEXT_HINT = '#9E9E9E';

// ألوان الخلفية
const BACKGROUND_LIGHT = '#F5F5F5';
const BACKGROUND_DARK = '#121212';
const SURFACE_LIGHT = '#FFFFFF';
const SURFACE_DARK = '#1E1E1E';

// ألوان الحالة
const SUCCESS = '#4CAF50';
const ERROR = '#F44336';
const WARNING = '#FFC107';
const INFO = '#2196F3';

// ألوان الوضع الليلي
const DARK_MODE = {
  primary: PRIMARY,
  primaryDark: PRIMARY_DARK,
  primaryLight: PRIMARY_LIGHT,
  accent: ACCENT,
  background: BACKGROUND_DARK,
  surface: SURFACE_DARK,
  text: '#FFFFFF',
  textSecondary: '#BBBBBB',
  textHint: '#888888',
  divider: '#333333',
  success: SUCCESS,
  error: ERROR,
  warning: WARNING,
  info: INFO,
};

// ألوان الوضع النهاري
const LIGHT_MODE = {
  primary: PRIMARY,
  primaryDark: PRIMARY_DARK,
  primaryLight: PRIMARY_LIGHT,
  accent: ACCENT,
  background: BACKGROUND_LIGHT,
  surface: SURFACE_LIGHT,
  text: TEXT_PRIMARY,
  textSecondary: TEXT_SECONDARY,
  textHint: TEXT_HINT,
  divider: '#E0E0E0',
  success: SUCCESS,
  error: ERROR,
  warning: WARNING,
  info: INFO,
};

/**
 * الحصول على ألوان الثيم بناءً على وضع الظلام
 * @param {boolean} darkMode - هل الوضع الليلي مفعل
 * @returns {Object} كائن يحتوي على ألوان الثيم
 */
const getThemeColors = (darkMode = false) => {
  return darkMode ? DARK_MODE : LIGHT_MODE;
};

export {
  PRIMARY,
  PRIMARY_DARK,
  PRIMARY_LIGHT,
  ACCENT,
  TEXT_PRIMARY,
  TEXT_SECONDARY,
  TEXT_HINT,
  BACKGROUND_LIGHT,
  BACKGROUND_DARK,
  SURFACE_LIGHT,
  SURFACE_DARK,
  SUCCESS,
  ERROR,
  WARNING,
  INFO,
  DARK_MODE,
  LIGHT_MODE,
  getThemeColors,
};
