/**
 * ملف أنماط النصوص للتطبيق
 */

import { Platform } from 'react-native';

// أحجام الخطوط
const FONT_SIZE = {
  small: {
    h1: 24,
    h2: 20,
    h3: 18,
    body: 14,
    caption: 12,
    button: 14,
    quranText: 20,
    athkarText: 16,
  },
  medium: {
    h1: 28,
    h2: 22,
    h3: 20,
    body: 16,
    caption: 14,
    button: 16,
    quranText: 24,
    athkarText: 18,
  },
  large: {
    h1: 32,
    h2: 26,
    h3: 22,
    body: 18,
    caption: 16,
    button: 18,
    quranText: 28,
    athkarText: 20,
  },
};

// أنواع الخطوط
const FONT_FAMILY = {
  default: {
    regular: Platform.OS === 'ios' ? 'System' : 'Roboto',
    medium: Platform.OS === 'ios' ? 'System' : 'Roboto-Medium',
    bold: Platform.OS === 'ios' ? 'System' : 'Roboto-Bold',
    light: Platform.OS === 'ios' ? 'System' : 'Roboto-Light',
  },
  uthmani: {
    regular: 'KFGQPC Uthmanic Script HAFS',
    medium: 'KFGQPC Uthmanic Script HAFS',
    bold: 'KFGQPC Uthmanic Script HAFS',
    light: 'KFGQPC Uthmanic Script HAFS',
  },
};

/**
 * الحصول على أنماط النصوص بناءً على حجم الخط ونوعه
 * @param {string} fontSize - حجم الخط (small, medium, large)
 * @param {string} fontType - نوع الخط (default, uthmani)
 * @returns {Object} كائن يحتوي على أنماط النصوص
 */
const getTypography = (fontSize = 'medium', fontType = 'default') => {
  const size = FONT_SIZE[fontSize] || FONT_SIZE.medium;
  const family = FONT_FAMILY[fontType] || FONT_FAMILY.default;

  return {
    h1: {
      fontSize: size.h1,
      fontFamily: family.bold,
      fontWeight: 'bold',
      lineHeight: size.h1 * 1.2,
    },
    h2: {
      fontSize: size.h2,
      fontFamily: family.bold,
      fontWeight: 'bold',
      lineHeight: size.h2 * 1.2,
    },
    h3: {
      fontSize: size.h3,
      fontFamily: family.medium,
      fontWeight: '500',
      lineHeight: size.h3 * 1.2,
    },
    body: {
      fontSize: size.body,
      fontFamily: family.regular,
      fontWeight: 'normal',
      lineHeight: size.body * 1.5,
    },
    caption: {
      fontSize: size.caption,
      fontFamily: family.light,
      fontWeight: '300',
      lineHeight: size.caption * 1.5,
    },
    button: {
      fontSize: size.button,
      fontFamily: family.medium,
      fontWeight: '500',
      lineHeight: size.button * 1.2,
    },
    quranText: {
      fontSize: size.quranText,
      fontFamily: fontType === 'uthmani' ? family.regular : family.regular,
      fontWeight: 'normal',
      lineHeight: size.quranText * 1.8,
      textAlign: 'right',
    },
    athkarText: {
      fontSize: size.athkarText,
      fontFamily: family.regular,
      fontWeight: 'normal',
      lineHeight: size.athkarText * 1.6,
      textAlign: 'right',
    },
  };
};

export {
  FONT_SIZE,
  FONT_FAMILY,
  getTypography,
};
