/**
 * ملف قيم التباعد للتطبيق
 */

// قيم التباعد الأساسية
const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

// هوامش الشاشة
const SCREEN_MARGIN = {
  horizontal: SPACING.md,
  vertical: SPACING.md,
};

// تباعد العناصر
const ELEMENT_SPACING = {
  between: SPACING.md,
  stack: SPACING.md,
};

// تباعد البطاقات
const CARD_SPACING = {
  margin: SPACING.sm,
  padding: SPACING.md,
  borderRadius: SPACING.sm,
};

// تباعد الأزرار
const BUTTON_SPACING = {
  padding: SPACING.md,
  margin: SPACING.sm,
  borderRadius: SPACING.sm,
};

// تباعد النصوص
const TEXT_SPACING = {
  paragraph: SPACING.md,
  title: SPACING.lg,
};

/**
 * الحصول على قيم التباعد
 * @returns {Object} كائن يحتوي على قيم التباعد
 */
const getSpacing = () => {
  return {
    ...SPACING,
    screen: SCREEN_MARGIN,
    element: ELEMENT_SPACING,
    card: CARD_SPACING,
    button: BUTTON_SPACING,
    text: TEXT_SPACING,
  };
};

export {
  SPACING,
  SCREEN_MARGIN,
  ELEMENT_SPACING,
  CARD_SPACING,
  BUTTON_SPACING,
  TEXT_SPACING,
  getSpacing,
};
