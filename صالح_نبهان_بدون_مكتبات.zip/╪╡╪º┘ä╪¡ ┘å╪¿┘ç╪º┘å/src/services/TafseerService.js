import axios from 'axios';

/**
 * خدمة للتعامل مع واجهة برمجة تطبيقات التفسير
 */
class TafseerService {
  constructor() {
    this.baseUrl = 'https://api.quran.com/api/v4';
    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 10000,
    });
  }

  /**
   * جلب قائمة التفاسير المتاحة
   * @returns {Promise} وعد يحتوي على قائمة التفاسير
   */
  async getTafseerList() {
    try {
      const response = await this.client.get('/resources/tafsirs');
      return response.data.tafsirs;
    } catch (error) {
      console.error('خطأ في جلب قائمة التفاسير:', error);
      throw error;
    }
  }

  /**
   * جلب تفسير آية محددة
   * @param {number} tafsirId - معرف التفسير
   * @param {number} surahNumber - رقم السورة
   * @param {number} ayahNumber - رقم الآية
   * @returns {Promise} وعد يحتوي على تفسير الآية
   */
  async getAyahTafseer(tafsirId, surahNumber, ayahNumber) {
    try {
      const response = await this.client.get(`/tafsirs/${tafsirId}/by_ayah/${surahNumber}/${ayahNumber}`);
      return response.data.tafsir;
    } catch (error) {
      console.error(`خطأ في جلب تفسير الآية ${surahNumber}:${ayahNumber} من التفسير ${tafsirId}:`, error);
      throw error;
    }
  }

  /**
   * جلب تفسير سورة كاملة
   * @param {number} tafsirId - معرف التفسير
   * @param {number} surahNumber - رقم السورة
   * @returns {Promise} وعد يحتوي على تفسير السورة
   */
  async getSurahTafseer(tafsirId, surahNumber) {
    try {
      const response = await this.client.get(`/tafsirs/${tafsirId}/by_chapter/${surahNumber}`);
      return response.data.tafsirs;
    } catch (error) {
      console.error(`خطأ في جلب تفسير السورة ${surahNumber} من التفسير ${tafsirId}:`, error);
      throw error;
    }
  }

  /**
   * جلب معلومات تفسير محدد
   * @param {number} tafsirId - معرف التفسير
   * @returns {Promise} وعد يحتوي على معلومات التفسير
   */
  async getTafseerInfo(tafsirId) {
    try {
      const response = await this.client.get(`/resources/tafsirs/${tafsirId}`);
      return response.data.tafsir;
    } catch (error) {
      console.error(`خطأ في جلب معلومات التفسير ${tafsirId}:`, error);
      throw error;
    }
  }
}

export default new TafseerService();
