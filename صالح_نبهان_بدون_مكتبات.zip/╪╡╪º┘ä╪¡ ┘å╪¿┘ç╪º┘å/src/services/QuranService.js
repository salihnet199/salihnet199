import axios from 'axios';

/**
 * خدمة للتعامل مع واجهة برمجة تطبيقات القرآن الكريم
 */
class QuranService {
  constructor() {
    this.baseUrl = 'https://api.quran.com/api/v4';
    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 10000,
    });
  }

  /**
   * جلب قائمة السور
   * @returns {Promise} وعد يحتوي على قائمة السور
   */
  async getSurahs() {
    try {
      const response = await this.client.get('/chapters');
      return response.data.chapters;
    } catch (error) {
      console.error('خطأ في جلب قائمة السور:', error);
      throw error;
    }
  }

  /**
   * جلب صفحة محددة من المصحف
   * @param {number} pageNumber - رقم الصفحة
   * @returns {Promise} وعد يحتوي على محتوى الصفحة
   */
  async getQuranPage(pageNumber) {
    try {
      const response = await this.client.get(`/quran/verses/uthmani?page_number=${pageNumber}`);
      return response.data.verses;
    } catch (error) {
      console.error(`خطأ في جلب الصفحة رقم ${pageNumber}:`, error);
      throw error;
    }
  }

  /**
   * جلب سورة محددة
   * @param {number} surahNumber - رقم السورة
   * @returns {Promise} وعد يحتوي على آيات السورة
   */
  async getSurah(surahNumber) {
    try {
      const response = await this.client.get(`/quran/verses/uthmani?chapter_number=${surahNumber}`);
      return response.data.verses;
    } catch (error) {
      console.error(`خطأ في جلب السورة رقم ${surahNumber}:`, error);
      throw error;
    }
  }

  /**
   * البحث في القرآن الكريم
   * @param {string} query - نص البحث
   * @param {number} page - رقم صفحة النتائج
   * @param {number} size - عدد النتائج في الصفحة
   * @returns {Promise} وعد يحتوي على نتائج البحث
   */
  async searchQuran(query, page = 1, size = 20) {
    try {
      const response = await this.client.get('/search', {
        params: {
          q: query,
          page,
          size
        }
      });
      return response.data.search.results;
    } catch (error) {
      console.error(`خطأ في البحث عن "${query}":`, error);
      throw error;
    }
  }

  /**
   * جلب معلومات السورة
   * @param {number} surahNumber - رقم السورة
   * @returns {Promise} وعد يحتوي على معلومات السورة
   */
  async getSurahInfo(surahNumber) {
    try {
      const response = await this.client.get(`/chapters/${surahNumber}`);
      return response.data.chapter;
    } catch (error) {
      console.error(`خطأ في جلب معلومات السورة رقم ${surahNumber}:`, error);
      throw error;
    }
  }
}

export default new QuranService();
