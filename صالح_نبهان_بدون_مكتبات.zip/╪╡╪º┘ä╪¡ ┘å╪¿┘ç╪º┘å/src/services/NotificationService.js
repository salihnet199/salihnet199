import * as Notifications from 'expo-notifications';
import * as Permissions from 'expo-permissions';
import { Platform } from 'react-native';

/**
 * خدمة لإدارة الإشعارات
 */
class NotificationService {
  constructor() {
    this.configure();
  }

  /**
   * تكوين الإشعارات
   */
  configure() {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
      }),
    });
  }

  /**
   * طلب إذن الإشعارات
   * @returns {Promise} وعد يحتوي على حالة الإذن
   */
  async requestPermissions() {
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'default',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#4CAF50',
      });
    }

    const { status: existingStatus } = await Permissions.getAsync(Permissions.NOTIFICATIONS);
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
      finalStatus = status;
    }

    return finalStatus === 'granted';
  }

  /**
   * جدولة إشعار
   * @param {Object} options - خيارات الإشعار
   * @param {string} options.title - عنوان الإشعار
   * @param {string} options.body - محتوى الإشعار
   * @param {Object} options.data - بيانات إضافية للإشعار
   * @param {Date} options.trigger - وقت إرسال الإشعار
   * @returns {Promise} وعد يحتوي على معرف الإشعار
   */
  async scheduleNotification({ title, body, data = {}, trigger }) {
    const hasPermission = await this.requestPermissions();
    
    if (!hasPermission) {
      console.warn('لم يتم منح إذن الإشعارات');
      return null;
    }

    return await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data,
        sound: true,
      },
      trigger,
    });
  }

  /**
   * جدولة إشعار أذكار الصباح
   * @param {number} hour - ساعة الإشعار
   * @param {number} minute - دقيقة الإشعار
   * @returns {Promise} وعد يحتوي على معرف الإشعار
   */
  async scheduleMorningAthkarNotification(hour = 7, minute = 0) {
    return this.scheduleNotification({
      title: 'أذكار الصباح',
      body: 'حان وقت أذكار الصباح، لا تنسى ذكر الله',
      data: { type: 'athkar', category: 'morning' },
      trigger: {
        hour,
        minute,
        repeats: true,
      },
    });
  }

  /**
   * جدولة إشعار أذكار المساء
   * @param {number} hour - ساعة الإشعار
   * @param {number} minute - دقيقة الإشعار
   * @returns {Promise} وعد يحتوي على معرف الإشعار
   */
  async scheduleEveningAthkarNotification(hour = 17, minute = 0) {
    return this.scheduleNotification({
      title: 'أذكار المساء',
      body: 'حان وقت أذكار المساء، لا تنسى ذكر الله',
      data: { type: 'athkar', category: 'evening' },
      trigger: {
        hour,
        minute,
        repeats: true,
      },
    });
  }

  /**
   * جدولة إشعار آية يومية
   * @param {number} hour - ساعة الإشعار
   * @param {number} minute - دقيقة الإشعار
   * @returns {Promise} وعد يحتوي على معرف الإشعار
   */
  async scheduleDailyVerseNotification(hour = 12, minute = 0) {
    return this.scheduleNotification({
      title: 'آية اليوم',
      body: 'تدبر آية اليوم وتأمل في معانيها',
      data: { type: 'daily_verse' },
      trigger: {
        hour,
        minute,
        repeats: true,
      },
    });
  }

  /**
   * إلغاء إشعار محدد
   * @param {string} notificationId - معرف الإشعار
   * @returns {Promise} وعد يشير إلى نجاح العملية
   */
  async cancelNotification(notificationId) {
    await Notifications.cancelScheduledNotificationAsync(notificationId);
  }

  /**
   * إلغاء جميع الإشعارات
   * @returns {Promise} وعد يشير إلى نجاح العملية
   */
  async cancelAllNotifications() {
    await Notifications.cancelAllScheduledNotificationsAsync();
  }
}

export default new NotificationService();
