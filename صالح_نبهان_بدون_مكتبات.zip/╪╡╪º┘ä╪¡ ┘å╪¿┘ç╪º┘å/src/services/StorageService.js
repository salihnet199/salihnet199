import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * خدمة للتعامل مع التخزين المحلي
 */
class StorageService {
  /**
   * حفظ بيانات في التخزين المحلي
   * @param {string} key - مفتاح التخزين
   * @param {any} value - القيمة المراد تخزينها
   * @returns {Promise} وعد يشير إلى نجاح العملية
   */
  async setItem(key, value) {
    try {
      const jsonValue = JSON.stringify(value);
      await AsyncStorage.setItem(key, jsonValue);
      return true;
    } catch (error) {
      console.error(`خطأ في حفظ البيانات بمفتاح ${key}:`, error);
      throw error;
    }
  }

  /**
   * استرجاع بيانات من التخزين المحلي
   * @param {string} key - مفتاح التخزين
   * @returns {Promise} وعد يحتوي على البيانات المسترجعة
   */
  async getItem(key) {
    try {
      const jsonValue = await AsyncStorage.getItem(key);
      return jsonValue != null ? JSON.parse(jsonValue) : null;
    } catch (error) {
      console.error(`خطأ في استرجاع البيانات بمفتاح ${key}:`, error);
      throw error;
    }
  }

  /**
   * حذف بيانات من التخزين المحلي
   * @param {string} key - مفتاح التخزين
   * @returns {Promise} وعد يشير إلى نجاح العملية
   */
  async removeItem(key) {
    try {
      await AsyncStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error(`خطأ في حذف البيانات بمفتاح ${key}:`, error);
      throw error;
    }
  }

  /**
   * حفظ إعدادات المستخدم
   * @param {Object} settings - إعدادات المستخدم
   * @returns {Promise} وعد يشير إلى نجاح العملية
   */
  async saveSettings(settings) {
    return this.setItem('settings', settings);
  }

  /**
   * استرجاع إعدادات المستخدم
   * @returns {Promise} وعد يحتوي على إعدادات المستخدم
   */
  async getSettings() {
    return this.getItem('settings');
  }

  /**
   * حفظ العلامات المرجعية
   * @param {Array} bookmarks - قائمة العلامات المرجعية
   * @returns {Promise} وعد يشير إلى نجاح العملية
   */
  async saveBookmarks(bookmarks) {
    return this.setItem('bookmarks', bookmarks);
  }

  /**
   * استرجاع العلامات المرجعية
   * @returns {Promise} وعد يحتوي على قائمة العلامات المرجعية
   */
  async getBookmarks() {
    return this.getItem('bookmarks') || [];
  }

  /**
   * حفظ آخر قراءة
   * @param {Object} lastRead - بيانات آخر قراءة
   * @returns {Promise} وعد يشير إلى نجاح العملية
   */
  async saveLastRead(lastRead) {
    return this.setItem('lastRead', lastRead);
  }

  /**
   * استرجاع آخر قراءة
   * @returns {Promise} وعد يحتوي على بيانات آخر قراءة
   */
  async getLastRead() {
    return this.getItem('lastRead');
  }

  /**
   * حفظ تقدم القراءة
   * @param {Object} progress - بيانات تقدم القراءة
   * @returns {Promise} وعد يشير إلى نجاح العملية
   */
  async saveProgress(progress) {
    return this.setItem('progress', progress);
  }

  /**
   * استرجاع تقدم القراءة
   * @returns {Promise} وعد يحتوي على بيانات تقدم القراءة
   */
  async getProgress() {
    return this.getItem('progress') || { quran: {}, athkar: {} };
  }
}

export default new StorageService();
