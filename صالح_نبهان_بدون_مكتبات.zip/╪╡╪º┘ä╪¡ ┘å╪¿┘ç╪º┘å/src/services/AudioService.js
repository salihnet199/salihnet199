import axios from 'axios';

/**
 * خدمة للتعامل مع واجهة برمجة تطبيقات التلاوات الصوتية
 */
class AudioService {
  constructor() {
    this.baseUrl = 'https://api.quran.com/api/v4';
    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 10000,
    });
  }

  /**
   * جلب قائمة القراء المتاحين
   * @returns {Promise} وعد يحتوي على قائمة القراء
   */
  async getReciters() {
    try {
      const response = await this.client.get('/resources/recitations');
      return response.data.recitations;
    } catch (error) {
      console.error('خطأ في جلب قائمة القراء:', error);
      throw error;
    }
  }

  /**
   * جلب تلاوة آية محددة
   * @param {number} reciterId - معرف القارئ
   * @param {number} surahNumber - رقم السورة
   * @param {number} ayahNumber - رقم الآية
   * @returns {Promise} وعد يحتوي على رابط ملف الصوت
   */
  async getAyahAudio(reciterId, surahNumber, ayahNumber) {
    try {
      const response = await this.client.get(`/recitations/${reciterId}/by_ayah/${surahNumber}/${ayahNumber}`);
      return response.data.audio_file;
    } catch (error) {
      console.error(`خطأ في جلب تلاوة الآية ${surahNumber}:${ayahNumber} للقارئ ${reciterId}:`, error);
      throw error;
    }
  }

  /**
   * جلب تلاوة سورة كاملة
   * @param {number} reciterId - معرف القارئ
   * @param {number} surahNumber - رقم السورة
   * @returns {Promise} وعد يحتوي على روابط ملفات الصوت
   */
  async getSurahAudio(reciterId, surahNumber) {
    try {
      const response = await this.client.get(`/recitations/${reciterId}/by_chapter/${surahNumber}`);
      return response.data.audio_files;
    } catch (error) {
      console.error(`خطأ في جلب تلاوة السورة ${surahNumber} للقارئ ${reciterId}:`, error);
      throw error;
    }
  }

  /**
   * جلب معلومات قارئ محدد
   * @param {number} reciterId - معرف القارئ
   * @returns {Promise} وعد يحتوي على معلومات القارئ
   */
  async getReciterInfo(reciterId) {
    try {
      const response = await this.client.get(`/resources/recitations/${reciterId}`);
      return response.data.recitation;
    } catch (error) {
      console.error(`خطأ في جلب معلومات القارئ ${reciterId}:`, error);
      throw error;
    }
  }
}

export default new AudioService();
