import axios from 'axios';

/**
 * خدمة للتعامل مع واجهة برمجة تطبيقات الأذكار
 */
class AthkarService {
  constructor() {
    this.baseUrl = 'https://api.hisnmuslim.com/api/v1';
    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 10000,
    });
  }

  /**
   * جلب أذكار الصباح
   * @returns {Promise} وعد يحتوي على أذكار الصباح
   */
  async getMorningAthkar() {
    try {
      const response = await this.client.get('/athkar/morning');
      return response.data;
    } catch (error) {
      console.error('خطأ في جلب أذكار الصباح:', error);
      throw error;
    }
  }

  /**
   * جلب أذكار المساء
   * @returns {Promise} وعد يحتوي على أذكار المساء
   */
  async getEveningAthkar() {
    try {
      const response = await this.client.get('/athkar/evening');
      return response.data;
    } catch (error) {
      console.error('خطأ في جلب أذكار المساء:', error);
      throw error;
    }
  }

  /**
   * جلب أذكار فئة محددة
   * @param {string} category - فئة الأذكار
   * @returns {Promise} وعد يحتوي على أذكار الفئة المحددة
   */
  async getCategoryAthkar(category) {
    try {
      const response = await this.client.get(`/athkar/${category}`);
      return response.data;
    } catch (error) {
      console.error(`خطأ في جلب أذكار فئة ${category}:`, error);
      throw error;
    }
  }

  /**
   * جلب جميع فئات الأذكار
   * @returns {Promise} وعد يحتوي على جميع فئات الأذكار
   */
  async getCategories() {
    try {
      const response = await this.client.get('/categories');
      return response.data.categories;
    } catch (error) {
      console.error('خطأ في جلب فئات الأذكار:', error);
      throw error;
    }
  }

  /**
   * جلب ذكر محدد بواسطة المعرف
   * @param {number} id - معرف الذكر
   * @returns {Promise} وعد يحتوي على الذكر المحدد
   */
  async getAthkarById(id) {
    try {
      const response = await this.client.get(`/athkar/id/${id}`);
      return response.data.athkar;
    } catch (error) {
      console.error(`خطأ في جلب الذكر رقم ${id}:`, error);
      throw error;
    }
  }
}

export default new AthkarService();
