import axios from 'axios';

/**
 * تكوين Axios لواجهة برمجة تطبيقات التلاوات الصوتية
 */
const audioAPI = axios.create({
  baseURL: 'https://api.quran.audio/api/v1',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

/**
 * دالة للتعامل مع أخطاء الطلبات
 * @param {Error} error - كائن الخطأ
 */
const handleApiError = (error) => {
  if (error.response) {
    // الخادم استجاب برمز حالة خارج نطاق 2xx
    console.error('خطأ في استجابة الخادم:', error.response.status, error.response.data);
    return {
      error: true,
      status: error.response.status,
      message: error.response.data.message || 'حدث خطأ في استجابة الخادم',
      data: error.response.data
    };
  } else if (error.request) {
    // لم يتم استلام استجابة من الخادم
    console.error('لم يتم استلام استجابة من الخادم:', error.request);
    return {
      error: true,
      status: 0,
      message: 'لم يتم استلام استجابة من الخادم، تحقق من اتصالك بالإنترنت',
      data: null
    };
  } else {
    // حدث خطأ أثناء إعداد الطلب
    console.error('خطأ في إعداد الطلب:', error.message);
    return {
      error: true,
      status: 0,
      message: error.message || 'حدث خطأ أثناء إعداد الطلب',
      data: null
    };
  }
};

/**
 * الحصول على قائمة القراء
 * @param {string} language - لغة البيانات (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على قائمة القراء
 */
export const getReciters = async (language = 'ar') => {
  try {
    const response = await audioAPI.get('/reciters', {
      params: { language }
    });
    return {
      error: false,
      data: response.data.reciters
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على معلومات قارئ محدد
 * @param {number} reciterId - معرف القارئ
 * @param {string} language - لغة البيانات (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على معلومات القارئ
 */
export const getReciterInfo = async (reciterId, language = 'ar') => {
  try {
    const response = await audioAPI.get(`/reciters/${reciterId}`, {
      params: { language }
    });
    return {
      error: false,
      data: response.data.reciter
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على تلاوات قارئ محدد
 * @param {number} reciterId - معرف القارئ
 * @returns {Promise} وعد يحتوي على تلاوات القارئ
 */
export const getReciterRecitations = async (reciterId) => {
  try {
    const response = await audioAPI.get(`/reciters/${reciterId}/recitations`);
    return {
      error: false,
      data: response.data.recitations
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على تلاوة سورة محددة لقارئ محدد
 * @param {number} reciterId - معرف القارئ
 * @param {number} surahId - معرف السورة
 * @returns {Promise} وعد يحتوي على تلاوة السورة
 */
export const getSurahRecitation = async (reciterId, surahId) => {
  try {
    const response = await audioAPI.get(`/reciters/${reciterId}/surahs/${surahId}`);
    return {
      error: false,
      data: response.data.recitation
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على تلاوة آية محددة لقارئ محدد
 * @param {number} reciterId - معرف القارئ
 * @param {number} surahId - معرف السورة
 * @param {number} ayahId - معرف الآية
 * @returns {Promise} وعد يحتوي على تلاوة الآية
 */
export const getAyahRecitation = async (reciterId, surahId, ayahId) => {
  try {
    const response = await audioAPI.get(`/reciters/${reciterId}/surahs/${surahId}/ayahs/${ayahId}`);
    return {
      error: false,
      data: response.data.recitation
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * البحث عن قراء
 * @param {string} query - نص البحث
 * @param {string} language - لغة البيانات (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchReciters = async (query, language = 'ar') => {
  try {
    const response = await audioAPI.get('/search/reciters', {
      params: { q: query, language }
    });
    return {
      error: false,
      data: response.data.results
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على قائمة أنماط التلاوة
 * @param {string} language - لغة البيانات (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على قائمة أنماط التلاوة
 */
export const getRecitationStyles = async (language = 'ar') => {
  try {
    const response = await audioAPI.get('/styles', {
      params: { language }
    });
    return {
      error: false,
      data: response.data.styles
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على قائمة القراء حسب نمط التلاوة
 * @param {number} styleId - معرف نمط التلاوة
 * @param {string} language - لغة البيانات (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على قائمة القراء
 */
export const getRecitersByStyle = async (styleId, language = 'ar') => {
  try {
    const response = await audioAPI.get(`/styles/${styleId}/reciters`, {
      params: { language }
    });
    return {
      error: false,
      data: response.data.reciters
    };
  } catch (error) {
    return handleApiError(error);
  }
};

export default {
  getReciters,
  getReciterInfo,
  getReciterRecitations,
  getSurahRecitation,
  getAyahRecitation,
  searchReciters,
  getRecitationStyles,
  getRecitersByStyle
};
