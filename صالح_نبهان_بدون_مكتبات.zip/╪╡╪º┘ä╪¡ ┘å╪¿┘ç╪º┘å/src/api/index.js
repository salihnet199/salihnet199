import quranAPI from '../api/quranAPI';
import athkarAPI from '../api/athkarAPI';
import audioAPI from '../api/audioAPI';
import searchAPI from '../api/searchAPI';

// تصدير جميع واجهات برمجة التطبيقات من ملف واحد
export {
  quranAPI,
  athkarAPI,
  audioAPI,
  searchAPI
};
