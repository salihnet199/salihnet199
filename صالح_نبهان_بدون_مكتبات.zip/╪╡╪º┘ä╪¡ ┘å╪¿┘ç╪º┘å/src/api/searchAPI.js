import axios from 'axios';

/**
 * تكوين Axios لواجهة برمجة تطبيقات البحث في القرآن
 */
const searchAPI = axios.create({
  baseURL: 'https://api.quran.com/api/v4/search',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

/**
 * دالة للتعامل مع أخطاء الطلبات
 * @param {Error} error - كائن الخطأ
 */
const handleApiError = (error) => {
  if (error.response) {
    // الخادم استجاب برمز حالة خارج نطاق 2xx
    console.error('خطأ في استجابة الخادم:', error.response.status, error.response.data);
    return {
      error: true,
      status: error.response.status,
      message: error.response.data.message || 'حدث خطأ في استجابة الخادم',
      data: error.response.data
    };
  } else if (error.request) {
    // لم يتم استلام استجابة من الخادم
    console.error('لم يتم استلام استجابة من الخادم:', error.request);
    return {
      error: true,
      status: 0,
      message: 'لم يتم استلام استجابة من الخادم، تحقق من اتصالك بالإنترنت',
      data: null
    };
  } else {
    // حدث خطأ أثناء إعداد الطلب
    console.error('خطأ في إعداد الطلب:', error.message);
    return {
      error: true,
      status: 0,
      message: error.message || 'حدث خطأ أثناء إعداد الطلب',
      data: null
    };
  }
};

/**
 * البحث في القرآن الكريم
 * @param {string} query - نص البحث
 * @param {number} page - رقم الصفحة
 * @param {number} size - عدد النتائج في الصفحة
 * @param {string} language - لغة البحث (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchQuran = async (query, page = 1, size = 20, language = 'ar') => {
  try {
    const response = await searchAPI.get('/', {
      params: {
        q: query,
        page,
        size,
        language
      }
    });
    return {
      error: false,
      data: response.data.search.results,
      total: response.data.search.total,
      page: response.data.search.current_page,
      totalPages: response.data.search.total_pages
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * البحث في القرآن الكريم حسب الكلمة
 * @param {string} query - نص البحث
 * @param {number} page - رقم الصفحة
 * @param {number} size - عدد النتائج في الصفحة
 * @param {string} language - لغة البحث (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchQuranByWord = async (query, page = 1, size = 20, language = 'ar') => {
  try {
    const response = await searchAPI.get('/word', {
      params: {
        q: query,
        page,
        size,
        language
      }
    });
    return {
      error: false,
      data: response.data.search.results,
      total: response.data.search.total,
      page: response.data.search.current_page,
      totalPages: response.data.search.total_pages
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * البحث في تفاسير القرآن الكريم
 * @param {string} query - نص البحث
 * @param {number} page - رقم الصفحة
 * @param {number} size - عدد النتائج في الصفحة
 * @param {string} language - لغة البحث (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchTafsir = async (query, page = 1, size = 20, language = 'ar') => {
  try {
    const response = await searchAPI.get('/tafsir', {
      params: {
        q: query,
        page,
        size,
        language
      }
    });
    return {
      error: false,
      data: response.data.search.results,
      total: response.data.search.total,
      page: response.data.search.current_page,
      totalPages: response.data.search.total_pages
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * البحث في ترجمات القرآن الكريم
 * @param {string} query - نص البحث
 * @param {number} page - رقم الصفحة
 * @param {number} size - عدد النتائج في الصفحة
 * @param {string} language - لغة البحث (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchTranslation = async (query, page = 1, size = 20, language = 'ar') => {
  try {
    const response = await searchAPI.get('/translation', {
      params: {
        q: query,
        page,
        size,
        language
      }
    });
    return {
      error: false,
      data: response.data.search.results,
      total: response.data.search.total,
      page: response.data.search.current_page,
      totalPages: response.data.search.total_pages
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * البحث المتقدم في القرآن الكريم
 * @param {Object} options - خيارات البحث
 * @param {string} options.query - نص البحث
 * @param {number} options.page - رقم الصفحة
 * @param {number} options.size - عدد النتائج في الصفحة
 * @param {string} options.language - لغة البحث (ar, en, etc.)
 * @param {Array} options.surahs - قائمة أرقام السور للبحث فيها
 * @param {Array} options.juzs - قائمة أرقام الأجزاء للبحث فيها
 * @param {Array} options.hizbs - قائمة أرقام الأحزاب للبحث فيها
 * @param {Array} options.rukus - قائمة أرقام الركوعات للبحث فيها
 * @param {Array} options.pages - قائمة أرقام الصفحات للبحث فيها
 * @param {Array} options.manzils - قائمة أرقام المنازل للبحث فيها
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const advancedSearch = async (options) => {
  const {
    query,
    page = 1,
    size = 20,
    language = 'ar',
    surahs = [],
    juzs = [],
    hizbs = [],
    rukus = [],
    pages = [],
    manzils = []
  } = options;

  try {
    const response = await searchAPI.get('/advanced', {
      params: {
        q: query,
        page,
        size,
        language,
        surahs: surahs.join(','),
        juzs: juzs.join(','),
        hizbs: hizbs.join(','),
        rukus: rukus.join(','),
        pages: pages.join(','),
        manzils: manzils.join(',')
      }
    });
    return {
      error: false,
      data: response.data.search.results,
      total: response.data.search.total,
      page: response.data.search.current_page,
      totalPages: response.data.search.total_pages
    };
  } catch (error) {
    return handleApiError(error);
  }
};

export default {
  searchQuran,
  searchQuranByWord,
  searchTafsir,
  searchTranslation,
  advancedSearch
};
