import axios from 'axios';

/**
 * تكوين Axios لواجهة برمجة تطبيقات الأذكار
 */
const athkarAPI = axios.create({
  baseURL: 'https://api.hisnmuslim.com/api/v1',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

/**
 * دالة للتعامل مع أخطاء الطلبات
 * @param {Error} error - كائن الخطأ
 */
const handleApiError = (error) => {
  if (error.response) {
    // الخادم استجاب برمز حالة خارج نطاق 2xx
    console.error('خطأ في استجابة الخادم:', error.response.status, error.response.data);
    return {
      error: true,
      status: error.response.status,
      message: error.response.data.message || 'حدث خطأ في استجابة الخادم',
      data: error.response.data
    };
  } else if (error.request) {
    // لم يتم استلام استجابة من الخادم
    console.error('لم يتم استلام استجابة من الخادم:', error.request);
    return {
      error: true,
      status: 0,
      message: 'لم يتم استلام استجابة من الخادم، تحقق من اتصالك بالإنترنت',
      data: null
    };
  } else {
    // حدث خطأ أثناء إعداد الطلب
    console.error('خطأ في إعداد الطلب:', error.message);
    return {
      error: true,
      status: 0,
      message: error.message || 'حدث خطأ أثناء إعداد الطلب',
      data: null
    };
  }
};

/**
 * الحصول على جميع فئات الأذكار
 * @returns {Promise} وعد يحتوي على قائمة فئات الأذكار
 */
export const getAthkarCategories = async () => {
  try {
    const response = await athkarAPI.get('/categories');
    return {
      error: false,
      data: response.data.categories
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على أذكار الصباح
 * @returns {Promise} وعد يحتوي على أذكار الصباح
 */
export const getMorningAthkar = async () => {
  try {
    const response = await athkarAPI.get('/athkar/morning');
    return {
      error: false,
      data: response.data.athkar
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على أذكار المساء
 * @returns {Promise} وعد يحتوي على أذكار المساء
 */
export const getEveningAthkar = async () => {
  try {
    const response = await athkarAPI.get('/athkar/evening');
    return {
      error: false,
      data: response.data.athkar
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على أذكار النوم
 * @returns {Promise} وعد يحتوي على أذكار النوم
 */
export const getSleepAthkar = async () => {
  try {
    const response = await athkarAPI.get('/athkar/sleep');
    return {
      error: false,
      data: response.data.athkar
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على أذكار الاستيقاظ
 * @returns {Promise} وعد يحتوي على أذكار الاستيقاظ
 */
export const getWakeupAthkar = async () => {
  try {
    const response = await athkarAPI.get('/athkar/wakeup');
    return {
      error: false,
      data: response.data.athkar
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على أذكار الصلاة
 * @returns {Promise} وعد يحتوي على أذكار الصلاة
 */
export const getPrayerAthkar = async () => {
  try {
    const response = await athkarAPI.get('/athkar/prayer');
    return {
      error: false,
      data: response.data.athkar
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على أذكار فئة محددة
 * @param {string} category - معرف الفئة
 * @returns {Promise} وعد يحتوي على أذكار الفئة المحددة
 */
export const getCategoryAthkar = async (category) => {
  try {
    const response = await athkarAPI.get(`/athkar/${category}`);
    return {
      error: false,
      data: response.data.athkar
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على ذكر محدد بواسطة المعرف
 * @param {number} id - معرف الذكر
 * @returns {Promise} وعد يحتوي على الذكر المحدد
 */
export const getAthkarById = async (id) => {
  try {
    const response = await athkarAPI.get(`/athkar/id/${id}`);
    return {
      error: false,
      data: response.data.athkar
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * البحث في الأذكار
 * @param {string} query - نص البحث
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchAthkar = async (query) => {
  try {
    const response = await athkarAPI.get('/search', {
      params: { q: query }
    });
    return {
      error: false,
      data: response.data.results
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على أذكار عشوائية
 * @param {number} count - عدد الأذكار المطلوبة
 * @returns {Promise} وعد يحتوي على أذكار عشوائية
 */
export const getRandomAthkar = async (count = 1) => {
  try {
    const response = await athkarAPI.get('/random', {
      params: { count }
    });
    return {
      error: false,
      data: response.data.athkar
    };
  } catch (error) {
    return handleApiError(error);
  }
};

export default {
  getAthkarCategories,
  getMorningAthkar,
  getEveningAthkar,
  getSleepAthkar,
  getWakeupAthkar,
  getPrayerAthkar,
  getCategoryAthkar,
  getAthkarById,
  searchAthkar,
  getRandomAthkar
};
