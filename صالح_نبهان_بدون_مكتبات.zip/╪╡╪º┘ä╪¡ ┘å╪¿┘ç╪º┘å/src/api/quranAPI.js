import axios from 'axios';

/**
 * تكوين Axios لواجهة برمجة تطبيقات القرآن الكريم
 */
const quranAPI = axios.create({
  baseURL: 'https://api.quran.com/api/v4',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

/**
 * دالة للتعامل مع أخطاء الطلبات
 * @param {Error} error - كائن الخطأ
 */
const handleApiError = (error) => {
  if (error.response) {
    // الخادم استجاب برمز حالة خارج نطاق 2xx
    console.error('خطأ في استجابة الخادم:', error.response.status, error.response.data);
    return {
      error: true,
      status: error.response.status,
      message: error.response.data.message || 'حدث خطأ في استجابة الخادم',
      data: error.response.data
    };
  } else if (error.request) {
    // لم يتم استلام استجابة من الخادم
    console.error('لم يتم استلام استجابة من الخادم:', error.request);
    return {
      error: true,
      status: 0,
      message: 'لم يتم استلام استجابة من الخادم، تحقق من اتصالك بالإنترنت',
      data: null
    };
  } else {
    // حدث خطأ أثناء إعداد الطلب
    console.error('خطأ في إعداد الطلب:', error.message);
    return {
      error: true,
      status: 0,
      message: error.message || 'حدث خطأ أثناء إعداد الطلب',
      data: null
    };
  }
};

/**
 * الحصول على قائمة السور
 * @returns {Promise} وعد يحتوي على قائمة السور
 */
export const getSurahs = async () => {
  try {
    const response = await quranAPI.get('/chapters');
    return {
      error: false,
      data: response.data.chapters
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على معلومات سورة محددة
 * @param {number} chapterId - رقم السورة
 * @param {string} language - لغة المعلومات (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على معلومات السورة
 */
export const getSurahInfo = async (chapterId, language = 'ar') => {
  try {
    const response = await quranAPI.get(`/chapters/${chapterId}`, {
      params: { language }
    });
    return {
      error: false,
      data: response.data.chapter
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على صفحة محددة من المصحف
 * @param {number} pageNumber - رقم الصفحة
 * @param {string} words - نوع النص (uthmani, indopak, imlaei)
 * @returns {Promise} وعد يحتوي على آيات الصفحة
 */
export const getQuranPage = async (pageNumber, words = 'uthmani') => {
  try {
    const response = await quranAPI.get(`/quran/verses/${words}`, {
      params: { page_number: pageNumber }
    });
    return {
      error: false,
      data: response.data.verses
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على آيات سورة محددة
 * @param {number} chapterId - رقم السورة
 * @param {string} words - نوع النص (uthmani, indopak, imlaei)
 * @returns {Promise} وعد يحتوي على آيات السورة
 */
export const getSurahVerses = async (chapterId, words = 'uthmani') => {
  try {
    const response = await quranAPI.get(`/quran/verses/${words}`, {
      params: { chapter_number: chapterId }
    });
    return {
      error: false,
      data: response.data.verses
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * البحث في القرآن الكريم
 * @param {string} query - نص البحث
 * @param {number} page - رقم الصفحة
 * @param {number} size - عدد النتائج في الصفحة
 * @param {string} language - لغة البحث (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على نتائج البحث
 */
export const searchQuran = async (query, page = 1, size = 20, language = 'ar') => {
  try {
    const response = await quranAPI.get('/search', {
      params: {
        q: query,
        page,
        size,
        language
      }
    });
    return {
      error: false,
      data: response.data.search.results,
      total: response.data.search.total,
      page: response.data.search.current_page,
      totalPages: response.data.search.total_pages
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على قائمة التفاسير المتاحة
 * @param {string} language - لغة التفاسير (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على قائمة التفاسير
 */
export const getTafsirs = async (language = 'ar') => {
  try {
    const response = await quranAPI.get('/resources/tafsirs', {
      params: { language }
    });
    return {
      error: false,
      data: response.data.tafsirs
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على تفسير آية محددة
 * @param {number} tafsirId - معرف التفسير
 * @param {number} verseKey - مفتاح الآية (مثال: "1:1" للفاتحة الآية 1)
 * @returns {Promise} وعد يحتوي على تفسير الآية
 */
export const getVerseTafsir = async (tafsirId, verseKey) => {
  try {
    const response = await quranAPI.get(`/tafsirs/${tafsirId}/by_ayah/${verseKey}`);
    return {
      error: false,
      data: response.data.tafsir
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على قائمة القراء المتاحين
 * @param {string} language - لغة معلومات القراء (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على قائمة القراء
 */
export const getReciters = async (language = 'ar') => {
  try {
    const response = await quranAPI.get('/resources/recitations', {
      params: { language }
    });
    return {
      error: false,
      data: response.data.recitations
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على تلاوة آية محددة
 * @param {number} recitationId - معرف التلاوة
 * @param {string} verseKey - مفتاح الآية (مثال: "1:1" للفاتحة الآية 1)
 * @returns {Promise} وعد يحتوي على رابط ملف الصوت
 */
export const getVerseAudio = async (recitationId, verseKey) => {
  try {
    const response = await quranAPI.get(`/recitations/${recitationId}/by_ayah/${verseKey}`);
    return {
      error: false,
      data: response.data.audio_file
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على تلاوة سورة كاملة
 * @param {number} recitationId - معرف التلاوة
 * @param {number} chapterId - رقم السورة
 * @returns {Promise} وعد يحتوي على روابط ملفات الصوت
 */
export const getSurahAudio = async (recitationId, chapterId) => {
  try {
    const response = await quranAPI.get(`/recitations/${recitationId}/by_chapter/${chapterId}`);
    return {
      error: false,
      data: response.data.audio_files
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على ترجمات الآيات
 * @param {string} verseKey - مفتاح الآية أو نطاق الآيات (مثال: "1:1-7" للفاتحة كاملة)
 * @param {number} translationId - معرف الترجمة
 * @returns {Promise} وعد يحتوي على ترجمات الآيات
 */
export const getVerseTranslations = async (verseKey, translationId) => {
  try {
    const response = await quranAPI.get(`/verses/by_key/${verseKey}/translations/${translationId}`);
    return {
      error: false,
      data: response.data.translations
    };
  } catch (error) {
    return handleApiError(error);
  }
};

/**
 * الحصول على قائمة الترجمات المتاحة
 * @param {string} language - لغة معلومات الترجمات (ar, en, etc.)
 * @returns {Promise} وعد يحتوي على قائمة الترجمات
 */
export const getTranslations = async (language = 'ar') => {
  try {
    const response = await quranAPI.get('/resources/translations', {
      params: { language }
    });
    return {
      error: false,
      data: response.data.translations
    };
  } catch (error) {
    return handleApiError(error);
  }
};

export default {
  getSurahs,
  getSurahInfo,
  getQuranPage,
  getSurahVerses,
  searchQuran,
  getTafsirs,
  getVerseTafsir,
  getReciters,
  getVerseAudio,
  getSurahAudio,
  getVerseTranslations,
  getTranslations
};
