import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import Card from './Card';
import IconButton from './IconButton';
import LoadingIndicator from './LoadingIndicator';
import AthkarCounter from './AthkarCounter';
import SearchBar from './SearchBar';
import { getThemeColors } from '../styles/colors';
import { getTypography } from '../styles/typography';
import { getSpacing } from '../styles/spacing';
import { createCommonStyles } from '../styles/common';

const AthkarList = ({ navigation, category = 'morning' }) => {
  const [athkarList, setAthkarList] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredAthkar, setFilteredAthkar] = useState([]);
  
  const { darkMode, fontSize } = useSelector(state => state.settings);
  
  const colors = getThemeColors(darkMode);
  const typography = getTypography(fontSize);
  const spacing = getSpacing();
  const commonStyles = createCommonStyles(darkMode, fontSize);
  
  // محاكاة تحميل الأذكار
  useEffect(() => {
    setIsLoading(true);
    
    // محاكاة استدعاء API
    setTimeout(() => {
      // بيانات وهمية للأذكار
      const dummyAthkar = [
        {
          id: 1,
          title: 'أذكار الاستيقاظ من النوم',
          text: 'الحمد لله الذي أحيانا بعد ما أماتنا وإليه النشور',
          count: 1,
          category: 'morning',
          reference: 'رواه البخاري',
        },
        {
          id: 2,
          title: 'دعاء لبس الثوب',
          text: 'الحمد لله الذي كساني هذا (الثوب) ورزقنيه من غير حول مني ولا قوة',
          count: 1,
          category: 'morning',
          reference: 'رواه أبو داود والترمذي',
        },
        {
          id: 3,
          title: 'أذكار الخروج من المنزل',
          text: 'بسم الله، توكلت على الله، ولا حول ولا قوة إلا بالله',
          count: 1,
          category: 'morning',
          reference: 'رواه أبو داود والترمذي',
        },
        {
          id: 4,
          title: 'أذكار الصباح',
          text: 'أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد، وهو على كل شيء قدير. رب أسألك خير ما في هذا اليوم وخير ما بعده، وأعوذ بك من شر ما في هذا اليوم وشر ما بعده، رب أعوذ بك من الكسل وسوء الكبر، رب أعوذ بك من عذاب في النار وعذاب في القبر',
          count: 1,
          category: 'morning',
          reference: 'رواه مسلم',
        },
        {
          id: 5,
          title: 'سيد الاستغفار',
          text: 'اللهم أنت ربي لا إله إلا أنت، خلقتني وأنا عبدك، وأنا على عهدك ووعدك ما استطعت، أعوذ بك من شر ما صنعت، أبوء لك بنعمتك علي، وأبوء بذنبي فاغفر لي فإنه لا يغفر الذنوب إلا أنت',
          count: 1,
          category: 'morning',
          reference: 'رواه البخاري',
        },
        {
          id: 6,
          title: 'التسبيح والتحميد',
          text: 'سبحان الله وبحمده',
          count: 100,
          category: 'morning',
          reference: 'رواه مسلم',
        },
        {
          id: 7,
          title: 'الباقيات الصالحات',
          text: 'سبحان الله، والحمد لله، ولا إله إلا الله، والله أكبر',
          count: 33,
          category: 'morning',
          reference: 'رواه مسلم',
        },
      ];
      
      // تصفية الأذكار حسب الفئة
      const filteredList = category === 'all' 
        ? dummyAthkar 
        : dummyAthkar.filter(thikr => thikr.category === category);
      
      setAthkarList(filteredList);
      setFilteredAthkar(filteredList);
      setIsLoading(false);
    }, 1000);
  }, [category]);
  
  // تصفية الأذكار حسب البحث
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredAthkar(athkarList);
    } else {
      const filtered = athkarList.filter(
        thikr => 
          thikr.title.includes(searchQuery) || 
          thikr.text.includes(searchQuery)
      );
      setFilteredAthkar(filtered);
    }
  }, [searchQuery, athkarList]);
  
  const handleSearch = (text) => {
    setSearchQuery(text);
  };
  
  const getCategoryTitle = () => {
    switch(category) {
      case 'morning': return 'أذكار الصباح';
      case 'evening': return 'أذكار المساء';
      case 'sleep': return 'أذكار النوم';
      case 'prayer': return 'أذكار الصلاة';
      case 'all': return 'جميع الأذكار';
      default: return 'الأذكار';
    }
  };
  
  const renderThikrItem = ({ item }) => (
    <Card style={styles.thikrCard}>
      <Text style={[styles.thikrTitle, { color: colors.text }]}>{item.title}</Text>
      <Text style={[styles.thikrText, { color: colors.text }]}>{item.text}</Text>
      
      <View style={styles.thikrFooter}>
        <Text style={[styles.thikrReference, { color: colors.textSecondary }]}>{item.reference}</Text>
        
        <View style={styles.counterContainer}>
          <AthkarCounter 
            total={item.count} 
            initialCount={0}
            onComplete={() => console.log(`تم الانتهاء من ${item.title}`)}
          />
        </View>
      </View>
    </Card>
  );
  
  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <LoadingIndicator text="جاري تحميل الأذكار..." />
      </View>
    );
  }
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.categoryTitle, { color: colors.text }]}>{getCategoryTitle()}</Text>
        
        <View style={styles.searchContainer}>
          <SearchBar
            placeholder="بحث في الأذكار..."
            value={searchQuery}
            onChangeText={handleSearch}
            onSubmit={() => {}}
          />
        </View>
      </View>
      
      {filteredAthkar.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="search" size={48} color={colors.textSecondary} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            لا توجد نتائج تطابق بحثك
          </Text>
        </View>
      ) : (
        <FlatList
          data={filteredAthkar}
          renderItem={renderThikrItem}
          keyExtractor={item => item.id.toString()}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContainer}
        />
      )}
      
      <View style={styles.categoryButtons}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <TouchableOpacity 
            style={[
              styles.categoryButton, 
              category === 'morning' && { backgroundColor: colors.primary }
            ]}
            onPress={() => navigation.replace('AthkarScreen', { category: 'morning' })}
          >
            <Text 
              style={[
                styles.categoryButtonText, 
                category === 'morning' ? { color: '#ffffff' } : { color: colors.text }
              ]}
            >
              الصباح
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[
              styles.categoryButton, 
              category === 'evening' && { backgroundColor: colors.primary }
            ]}
            onPress={() => navigation.replace('AthkarScreen', { category: 'evening' })}
          >
            <Text 
              style={[
                styles.categoryButtonText, 
                category === 'evening' ? { color: '#ffffff' } : { color: colors.text }
              ]}
            >
              المساء
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[
              styles.categoryButton, 
              category === 'sleep' && { backgroundColor: colors.primary }
            ]}
            onPress={() => navigation.replace('AthkarScreen', { category: 'sleep' })}
          >
            <Text 
              style={[
                styles.categoryButtonText, 
                category === 'sleep' ? { color: '#ffffff' } : { color: colors.text }
              ]}
            >
              النوم
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[
              styles.categoryButton, 
              category === 'prayer' && { backgroundColor: colors.primary }
            ]}
            onPress={() => navigation.replace('AthkarScreen', { category: 'prayer' })}
          >
            <Text 
              style={[
                styles.categoryButtonText, 
                category === 'prayer' ? { color: '#ffffff' } : { color: colors.text }
              ]}
            >
              الصلاة
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[
              styles.categoryButton, 
              category === 'all' && { backgroundColor: colors.primary }
            ]}
            onPress={() => navigation.replace('AthkarScreen', { category: 'all' })}
          >
            <Text 
              style={[
                styles.categoryButtonText, 
                category === 'all' ? { color: '#ffffff' } : { color: colors.text }
              ]}
            >
              الكل
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    marginBottom: 16,
  },
  categoryTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  searchContainer: {
    marginBottom: 8,
  },
  listContainer: {
    paddingBottom: 80, // للسماح بمساحة للأزرار في الأسفل
  },
  thikrCard: {
    marginBottom: 16,
  },
  thikrTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'right',
  },
  thikrText: {
    fontSize: 16,
    lineHeight: 28,
    textAlign: 'right',
    marginBottom: 16,
  },
  thikrFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 12,
  },
  thikrReference: {
    fontSize: 14,
  },
  counterContainer: {
    flex: 1,
    maxWidth: 120,
  },
  categoryButtons: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: '#f0f0f0',
  },
  categoryButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    marginTop: 16,
  },
});

export default AthkarList;
