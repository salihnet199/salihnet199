import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * مكون عرض آية مع خيارات التفاعل
 * @param {Object} props - خصائص المكون
 * @param {Object} props.ayah - بيانات الآية
 * @param {Function} props.onPlayAudio - دالة تُنفذ عند طلب تشغيل الصوت
 * @param {Function} props.onShowTafseer - دالة تُنفذ عند طلب عرض التفسير
 * @param {Function} props.onAddBookmark - دالة تُنفذ عند إضافة علامة مرجعية
 * @param {boolean} props.isBookmarked - هل الآية مضافة للعلامات المرجعية
 * @param {Object} props.style - أنماط إضافية للحاوية
 */
const AyahRenderer = ({ 
  ayah, 
  onPlayAudio, 
  onShowTafseer, 
  onAddBookmark,
  isBookmarked = false,
  style 
}) => {
  if (!ayah) return null;
  
  return (
    <View style={[styles.container, style]}>
      <View style={styles.header}>
        <View style={styles.ayahNumberContainer}>
          <Text style={styles.ayahNumber}>{ayah.number}</Text>
        </View>
        
        <View style={styles.actionsContainer}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => onPlayAudio && onPlayAudio(ayah)}
          >
            <Ionicons name="play-circle-outline" size={24} color="#4CAF50" />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => onShowTafseer && onShowTafseer(ayah)}
          >
            <Ionicons name="book-outline" size={24} color="#2196F3" />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => onAddBookmark && onAddBookmark(ayah)}
          >
            <Ionicons 
              name={isBookmarked ? "bookmark" : "bookmark-outline"} 
              size={24} 
              color={isBookmarked ? "#FFC107" : "#757575"} 
            />
          </TouchableOpacity>
        </View>
      </View>
      
      <ScrollView style={styles.textContainer}>
        <Text style={styles.arabicText}>{ayah.text}</Text>
        
        {ayah.translation && (
          <Text style={styles.translationText}>{ayah.translation}</Text>
        )}
      </ScrollView>
      
      <View style={styles.footer}>
        <Text style={styles.surahInfo}>
          {ayah.surah_name} ({ayah.surah_number}) - الآية {ayah.number}
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 8,
    padding: 16,
    backgroundColor: '#ffffff',
    marginVertical: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  ayahNumberContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ayahNumber: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  actionsContainer: {
    flexDirection: 'row',
  },
  actionButton: {
    padding: 8,
    marginLeft: 4,
  },
  textContainer: {
    maxHeight: 200,
  },
  arabicText: {
    fontSize: 22,
    lineHeight: 40,
    textAlign: 'right',
    color: '#212121',
    fontFamily: 'System',
    marginBottom: 12,
  },
  translationText: {
    fontSize: 16,
    lineHeight: 24,
    textAlign: 'left',
    color: '#757575',
    marginBottom: 8,
  },
  footer: {
    marginTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 8,
  },
  surahInfo: {
    fontSize: 14,
    color: '#9e9e9e',
    textAlign: 'center',
  },
});

export default AyahRenderer;
