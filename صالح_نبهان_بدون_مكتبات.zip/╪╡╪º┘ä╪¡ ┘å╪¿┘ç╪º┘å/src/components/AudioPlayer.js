import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * مكون مشغل صوتي للتلاوات
 * @param {Object} props - خصائص المكون
 * @param {string} props.audioUrl - رابط ملف الصوت
 * @param {Object} props.ayahData - بيانات الآية المرتبطة بالصوت
 * @param {Function} props.onPlaybackStatusChange - دالة تُنفذ عند تغيير حالة التشغيل
 * @param {boolean} props.autoPlay - تشغيل تلقائي للصوت
 * @param {Object} props.style - أنماط إضافية للحاوية
 */
const AudioPlayer = ({ 
  audioUrl, 
  ayahData, 
  onPlaybackStatusChange,
  autoPlay = false,
  style 
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [position, setPosition] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [repeatMode, setRepeatMode] = useState('none'); // none, single, range
  
  // محاكاة تحميل وتشغيل الصوت
  useEffect(() => {
    if (audioUrl) {
      setIsLoading(true);
      
      // محاكاة تحميل الصوت
      const loadingTimeout = setTimeout(() => {
        setIsLoading(false);
        setDuration(180); // 3 دقائق كمثال
        
        if (autoPlay) {
          setIsPlaying(true);
        }
      }, 1500);
      
      return () => clearTimeout(loadingTimeout);
    }
  }, [audioUrl, autoPlay]);
  
  // محاكاة تقدم التشغيل
  useEffect(() => {
    let interval;
    
    if (isPlaying && !isLoading) {
      interval = setInterval(() => {
        setPosition(prev => {
          if (prev >= duration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, isLoading, duration]);
  
  // إخطار بتغيير حالة التشغيل
  useEffect(() => {
    if (onPlaybackStatusChange) {
      onPlaybackStatusChange({
        isPlaying,
        duration,
        position,
        isLoading,
        repeatMode
      });
    }
  }, [isPlaying, duration, position, isLoading, repeatMode, onPlaybackStatusChange]);
  
  const togglePlayPause = () => {
    if (isLoading) return;
    setIsPlaying(prev => !prev);
  };
  
  const stop = () => {
    setIsPlaying(false);
    setPosition(0);
  };
  
  const seekTo = (value) => {
    if (isLoading) return;
    setPosition(value);
  };
  
  const toggleRepeatMode = () => {
    setRepeatMode(prev => {
      switch(prev) {
        case 'none': return 'single';
        case 'single': return 'range';
        case 'range': return 'none';
        default: return 'none';
      }
    });
  };
  
  // تنسيق الوقت (ثواني -> mm:ss)
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // حساب نسبة التقدم
  const progressPercentage = duration > 0 ? (position / duration) * 100 : 0;
  
  return (
    <View style={[styles.container, style]}>
      {ayahData && (
        <View style={styles.ayahInfo}>
          <Text style={styles.surahName}>{ayahData.surah_name}</Text>
          <Text style={styles.ayahNumber}>الآية {ayahData.number}</Text>
        </View>
      )}
      
      <View style={styles.progressContainer}>
        <View style={styles.progressBackground}>
          <View 
            style={[
              styles.progressFill, 
              { width: `${progressPercentage}%` }
            ]} 
          />
        </View>
        
        <View style={styles.timeInfo}>
          <Text style={styles.timeText}>{formatTime(position)}</Text>
          <Text style={styles.timeText}>{formatTime(duration)}</Text>
        </View>
      </View>
      
      <View style={styles.controls}>
        <TouchableOpacity 
          style={styles.controlButton}
          onPress={toggleRepeatMode}
        >
          <Ionicons 
            name={
              repeatMode === 'none' 
                ? 'repeat-outline' 
                : repeatMode === 'single' 
                  ? 'repeat' 
                  : 'sync'
            } 
            size={24} 
            color={repeatMode === 'none' ? '#757575' : '#4CAF50'} 
          />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.controlButton}
          onPress={() => seekTo(Math.max(0, position - 10))}
          disabled={isLoading}
        >
          <Ionicons name="play-back" size={24} color={isLoading ? '#bdbdbd' : '#212121'} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.playPauseButton}
          onPress={togglePlayPause}
          disabled={isLoading}
        >
          {isLoading ? (
            <Ionicons name="hourglass-outline" size={32} color="#ffffff" />
          ) : isPlaying ? (
            <Ionicons name="pause" size={32} color="#ffffff" />
          ) : (
            <Ionicons name="play" size={32} color="#ffffff" />
          )}
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.controlButton}
          onPress={() => seekTo(Math.min(duration, position + 10))}
          disabled={isLoading}
        >
          <Ionicons name="play-forward" size={24} color={isLoading ? '#bdbdbd' : '#212121'} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.controlButton}
          onPress={stop}
          disabled={isLoading}
        >
          <Ionicons name="stop" size={24} color={isLoading ? '#bdbdbd' : '#212121'} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    borderRadius: 8,
    padding: 16,
    backgroundColor: '#ffffff',
    marginVertical: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  ayahInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  surahName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#212121',
  },
  ayahNumber: {
    fontSize: 16,
    color: '#757575',
  },
  progressContainer: {
    marginBottom: 16,
  },
  progressBackground: {
    height: 8,
    backgroundColor: '#f0f0f0',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
  },
  timeInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  timeText: {
    fontSize: 12,
    color: '#757575',
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  controlButton: {
    padding: 8,
  },
  playPauseButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default AudioPlayer;
