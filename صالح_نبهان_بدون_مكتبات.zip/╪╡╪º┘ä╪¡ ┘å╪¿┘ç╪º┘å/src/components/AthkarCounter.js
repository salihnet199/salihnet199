import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * مكون عداد للأذكار مع دعم التكرار والإعادة
 * @param {Object} props - خصائص المكون
 * @param {number} props.total - العدد الإجمالي المطلوب
 * @param {number} props.initialCount - العدد الأولي
 * @param {Function} props.onComplete - دالة تُنفذ عند اكتمال العدد
 * @param {Function} props.onCountChange - دالة تُنفذ عند تغيير العدد
 * @param {Object} props.style - أنماط إضافية للحاوية
 */
const AthkarCounter = ({ 
  total = 33, 
  initialCount = 0, 
  onComplete, 
  onCountChange,
  style 
}) => {
  const [count, setCount] = useState(initialCount);
  const isCompleted = count >= total;
  
  useEffect(() => {
    if (onCountChange) {
      onCountChange(count);
    }
    
    if (isCompleted && onComplete) {
      onComplete();
    }
  }, [count, isCompleted, onComplete, onCountChange]);
  
  const incrementCount = () => {
    if (!isCompleted) {
      setCount(prevCount => prevCount + 1);
    }
  };
  
  const resetCount = () => {
    setCount(0);
  };
  
  return (
    <View style={[styles.container, style]}>
      <View style={styles.counterDisplay}>
        <Text style={styles.countText}>{count}</Text>
        <Text style={styles.totalText}>/ {total}</Text>
      </View>
      
      <View style={styles.buttonsContainer}>
        <TouchableOpacity 
          style={[styles.counterButton, isCompleted && styles.disabledButton]}
          onPress={incrementCount}
          disabled={isCompleted}
        >
          <Text style={styles.buttonText}>تسبيح</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.resetButton}
          onPress={resetCount}
        >
          <Ionicons name="refresh" size={20} color="#ffffff" />
        </TouchableOpacity>
      </View>
      
      {isCompleted && (
        <View style={styles.completedBadge}>
          <Ionicons name="checkmark-circle" size={20} color="#4CAF50" />
          <Text style={styles.completedText}>تم</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 8,
    padding: 16,
    backgroundColor: '#f5f5f5',
    marginVertical: 8,
  },
  counterDisplay: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'baseline',
    marginBottom: 16,
  },
  countText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  totalText: {
    fontSize: 18,
    color: '#757575',
    marginLeft: 4,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  counterButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    borderRadius: 4,
    alignItems: 'center',
    marginRight: 8,
  },
  disabledButton: {
    backgroundColor: '#a5d6a7',
  },
  resetButton: {
    backgroundColor: '#f44336',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 4,
    alignItems: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
  },
  completedText: {
    color: '#4CAF50',
    fontWeight: 'bold',
    marginLeft: 4,
  },
});

export default AthkarCounter;
