import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';

/**
 * مكون مؤشر تحميل موحد
 * @param {Object} props - خصائص المكون
 * @param {string} props.size - حجم مؤشر التحميل (small, large)
 * @param {string} props.color - لون مؤشر التحميل
 * @param {string} props.text - نص اختياري يظهر مع مؤشر التحميل
 * @param {Object} props.style - أنماط إضافية للحاوية
 */
const LoadingIndicator = ({ 
  size = 'large', 
  color = '#4CAF50', 
  text, 
  style 
}) => {
  return (
    <View style={[styles.container, style]}>
      <ActivityIndicator size={size} color={color} />
      {text && <Text style={[styles.text, { color }]}>{text}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  text: {
    marginTop: 16,
    fontSize: 16,
    textAlign: 'center',
  },
});

export default LoadingIndicator;
