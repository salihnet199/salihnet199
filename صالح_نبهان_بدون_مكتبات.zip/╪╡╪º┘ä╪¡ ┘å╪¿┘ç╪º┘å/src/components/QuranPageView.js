import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, useColorScheme } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import Card from '../components/Card';
import { getThemeColors } from '../styles/colors';
import { getTypography } from '../styles/typography';
import { getSpacing } from '../styles/spacing';
import { createCommonStyles } from '../styles/common';
import StorageService from '../services/StorageService';

const QuranPageView = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageContent, setPageContent] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(1);
  
  const { darkMode, fontSize } = useSelector(state => state.settings);
  const colors = getThemeColors(darkMode);
  const typography = getTypography(fontSize);
  const spacing = getSpacing();
  const commonStyles = createCommonStyles(darkMode, fontSize);
  
  // محاكاة تحميل صفحة المصحف
  useEffect(() => {
    setIsLoading(true);
    
    // محاكاة استدعاء API
    setTimeout(() => {
      // بيانات وهمية لصفحة المصحف
      const dummyPageContent = {
        page: currentPage,
        sura_name: 'الفاتحة',
        ayahs: [
          { id: 1, text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', number: 1 },
          { id: 2, text: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', number: 2 },
          { id: 3, text: 'الرَّحْمَٰنِ الرَّحِيمِ', number: 3 },
          { id: 4, text: 'مَالِكِ يَوْمِ الدِّينِ', number: 4 },
          { id: 5, text: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ', number: 5 },
          { id: 6, text: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', number: 6 },
          { id: 7, text: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ', number: 7 },
        ]
      };
      
      setPageContent(dummyPageContent);
      setIsLoading(false);
      
      // حفظ آخر قراءة
      StorageService.saveLastRead({
        page: currentPage,
        surahNumber: 1,
        ayahNumber: 1,
        timestamp: new Date().getTime()
      });
    }, 1000);
  }, [currentPage]);
  
  const handleNextPage = () => {
    if (currentPage < 604) {
      setCurrentPage(currentPage + 1);
    }
  };
  
  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  
  const handleZoomIn = () => {
    if (zoomLevel < 1.5) {
      setZoomLevel(zoomLevel + 0.1);
    }
  };
  
  const handleZoomOut = () => {
    if (zoomLevel > 0.8) {
      setZoomLevel(zoomLevel - 0.1);
    }
  };
  
  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={[styles.loadingText, { color: colors.text }]}>جاري تحميل الصفحة...</Text>
      </View>
    );
  }
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>
          {pageContent.sura_name} - صفحة {currentPage}
        </Text>
      </View>
      
      <View style={styles.zoomControls}>
        <TouchableOpacity style={styles.zoomButton} onPress={handleZoomIn}>
          <Ionicons name="add" size={24} color={colors.primary} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.zoomButton} onPress={handleZoomOut}>
          <Ionicons name="remove" size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>
      
      <ScrollView style={styles.pageContent}>
        <View style={[styles.quranPage, { transform: [{ scale: zoomLevel }] }]}>
          <View style={styles.bismillah}>
            <Text style={[styles.bismillahText, { color: colors.text, fontSize: typography.quranText.fontSize }]}>
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </Text>
          </View>
          
          {pageContent.ayahs.map((ayah) => (
            <View key={ayah.id} style={styles.ayahContainer}>
              <Text style={[styles.ayahText, { color: colors.text, fontSize: typography.quranText.fontSize * zoomLevel }]}>
                {ayah.text}
              </Text>
              <View style={styles.ayahNumber}>
                <Text style={styles.ayahNumberText}>{ayah.number}</Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
      
      <View style={styles.navigationControls}>
        <TouchableOpacity 
          style={[styles.navButton, { backgroundColor: colors.primary }]}
          onPress={handlePrevPage}
          disabled={currentPage === 1}
        >
          <Ionicons name="chevron-back" size={24} color="#ffffff" />
        </TouchableOpacity>
        
        <Text style={[styles.pageNumber, { color: colors.text }]}>
          {currentPage} / 604
        </Text>
        
        <TouchableOpacity 
          style={[styles.navButton, { backgroundColor: colors.primary }]}
          onPress={handleNextPage}
          disabled={currentPage === 604}
        >
          <Ionicons name="chevron-forward" size={24} color="#ffffff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginBottom: 16,
  },
  pageTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  loadingText: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 20,
  },
  zoomControls: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 8,
  },
  zoomButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  pageContent: {
    flex: 1,
    marginBottom: 16,
  },
  quranPage: {
    padding: 16,
    backgroundColor: '#fffaf0',
    borderRadius: 8,
    minHeight: 500,
  },
  bismillah: {
    alignItems: 'center',
    marginBottom: 20,
  },
  bismillahText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  ayahContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginBottom: 10,
    position: 'relative',
  },
  ayahText: {
    fontSize: 22,
    lineHeight: 40,
    textAlign: 'right',
  },
  ayahNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  ayahNumberText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  navigationControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 16,
  },
  navButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pageNumber: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default QuranPageView;
