import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, useWindowDimensions } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import Card from './Card';
import IconButton from './IconButton';
import LoadingIndicator from './LoadingIndicator';
import { getThemeColors } from '../styles/colors';
import { getTypography } from '../styles/typography';
import { getSpacing } from '../styles/spacing';
import { createCommonStyles } from '../styles/common';

const HomeScreenGrid = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { darkMode, fontSize } = useSelector(state => state.settings);
  const { lastRead } = useSelector(state => state.quran);
  
  const colors = getThemeColors(darkMode);
  const typography = getTypography(fontSize);
  const spacing = getSpacing();
  const commonStyles = createCommonStyles(darkMode, fontSize);
  
  // حساب عرض العنصر بناءً على عرض الشاشة
  const itemWidth = (width - spacing.md * 3) / 2;
  
  // قائمة الميزات الرئيسية
  const features = [
    {
      id: 'quran',
      title: 'القرآن الكريم',
      description: 'قراءة القرآن الكريم بتصميم المصحف',
      icon: 'book',
      screen: 'QuranScreen',
      color: '#4CAF50'
    },
    {
      id: 'athkar',
      title: 'الأذكار اليومية',
      description: 'أذكار الصباح والمساء وأذكار متنوعة',
      icon: 'heart',
      screen: 'AthkarScreen',
      color: '#2196F3'
    },
    {
      id: 'tafseer',
      title: 'التفسير',
      description: 'تفاسير متعددة للقرآن الكريم',
      icon: 'document-text',
      screen: 'TafseerScreen',
      color: '#9C27B0'
    },
    {
      id: 'audio',
      title: 'التلاوات الصوتية',
      description: 'استماع للقرآن بأصوات مختلفة',
      icon: 'musical-notes',
      screen: 'AudioScreen',
      color: '#FF9800'
    },
    {
      id: 'search',
      title: 'البحث',
      description: 'البحث في القرآن الكريم',
      icon: 'search',
      screen: 'SearchScreen',
      color: '#F44336'
    },
    {
      id: 'stats',
      title: 'الإحصائيات',
      description: 'تتبع تقدمك في القراءة والأذكار',
      icon: 'stats-chart',
      screen: 'StatsScreen',
      color: '#607D8B'
    }
  ];
  
  const renderFeatureItem = (item) => (
    <TouchableOpacity
      key={item.id}
      style={[
        styles.featureItem,
        {
          width: itemWidth,
          backgroundColor: colors.surface,
        }
      ]}
      onPress={() => navigation.navigate(item.screen)}
    >
      <View style={[styles.iconContainer, { backgroundColor: item.color }]}>
        <Ionicons name={item.icon} size={32} color="#ffffff" />
      </View>
      <Text style={[styles.featureTitle, { color: colors.text }]}>{item.title}</Text>
      <Text style={[styles.featureDescription, { color: colors.textSecondary }]} numberOfLines={2}>
        {item.description}
      </Text>
    </TouchableOpacity>
  );
  
  const renderLastRead = () => {
    if (!lastRead) return null;
    
    return (
      <Card style={styles.lastReadCard} onPress={() => navigation.navigate('QuranScreen', { page: lastRead.page })}>
        <View style={styles.lastReadContent}>
          <View>
            <Text style={[styles.lastReadTitle, { color: colors.text }]}>آخر قراءة</Text>
            <Text style={[styles.lastReadInfo, { color: colors.textSecondary }]}>
              سورة {lastRead.surahName || 'الفاتحة'} - صفحة {lastRead.page || 1}
            </Text>
            <Text style={[styles.lastReadDate, { color: colors.textHint }]}>
              {lastRead.timestamp ? new Date(lastRead.timestamp).toLocaleDateString('ar-SA') : 'اليوم'}
            </Text>
          </View>
          <IconButton
            name="arrow-forward"
            size={24}
            color={colors.primary}
          />
        </View>
      </Card>
    );
  };
  
  const renderDailyWird = () => {
    return (
      <Card style={styles.dailyWirdCard}>
        <View style={styles.dailyWirdHeader}>
          <Text style={[styles.dailyWirdTitle, { color: colors.text }]}>ورد اليوم</Text>
          <IconButton
            name="refresh"
            size={20}
            color={colors.primary}
          />
        </View>
        
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '35%', backgroundColor: colors.primary }]} />
          </View>
          <Text style={[styles.progressText, { color: colors.textSecondary }]}>35% مكتمل</Text>
        </View>
        
        <View style={styles.dailyTasks}>
          <TouchableOpacity style={styles.taskItem} onPress={() => navigation.navigate('AthkarScreen', { category: 'morning' })}>
            <Ionicons name="checkmark-circle" size={24} color="#4CAF50" />
            <Text style={[styles.taskText, { color: colors.text }]}>أذكار الصباح</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.taskItem} onPress={() => navigation.navigate('AthkarScreen', { category: 'evening' })}>
            <Ionicons name="ellipse-outline" size={24} color={colors.textSecondary} />
            <Text style={[styles.taskText, { color: colors.text }]}>أذكار المساء</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.taskItem} onPress={() => navigation.navigate('QuranScreen')}>
            <Ionicons name="ellipse-outline" size={24} color={colors.textSecondary} />
            <Text style={[styles.taskText, { color: colors.text }]}>قراءة صفحة من القرآن</Text>
          </TouchableOpacity>
        </View>
      </Card>
    );
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={[styles.bismillah, { color: colors.text }]}>بسم الله الرحمن الرحيم</Text>
          <Text style={[styles.appTitle, { color: colors.text }]}>تطبيق إسلامي متكامل</Text>
        </View>
        
        {renderLastRead()}
        {renderDailyWird()}
        
        <Text style={[styles.sectionTitle, { color: colors.text }]}>الميزات الرئيسية</Text>
        
        <View style={styles.featuresGrid}>
          {features.map(renderFeatureItem)}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginVertical: 20,
  },
  bismillah: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  appTitle: {
    fontSize: 18,
    marginBottom: 16,
  },
  lastReadCard: {
    marginBottom: 16,
  },
  lastReadContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  lastReadTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  lastReadInfo: {
    fontSize: 16,
    marginBottom: 4,
  },
  lastReadDate: {
    fontSize: 14,
  },
  dailyWirdCard: {
    marginBottom: 16,
  },
  dailyWirdHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  dailyWirdTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  progressContainer: {
    marginBottom: 12,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#f0f0f0',
    borderRadius: 4,
    marginBottom: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
  },
  progressText: {
    fontSize: 14,
    textAlign: 'right',
  },
  dailyTasks: {
    marginTop: 8,
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  taskText: {
    fontSize: 16,
    marginLeft: 12,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    marginTop: 8,
  },
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  featureItem: {
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'right',
  },
  featureDescription: {
    fontSize: 14,
    textAlign: 'right',
  },
});

export default HomeScreenGrid;
