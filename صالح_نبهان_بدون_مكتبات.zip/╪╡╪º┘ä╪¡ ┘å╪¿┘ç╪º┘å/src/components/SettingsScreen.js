import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TouchableOpacity, Alert } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import Card from './Card';
import IconButton from './IconButton';
import { getThemeColors } from '../styles/colors';
import { getTypography } from '../styles/typography';
import { getSpacing } from '../styles/spacing';
import { createCommonStyles } from '../styles/common';
import NotificationService from '../services/NotificationService';
import StorageService from '../services/StorageService';

const SettingsScreen = () => {
  const dispatch = useDispatch();
  const { darkMode, fontSize, fontType, notificationsEnabled } = useSelector(state => state.settings);
  
  const [isDarkMode, setIsDarkMode] = useState(darkMode);
  const [selectedFontSize, setSelectedFontSize] = useState(fontSize);
  const [selectedFontType, setSelectedFontType] = useState(fontType);
  const [areNotificationsEnabled, setAreNotificationsEnabled] = useState(notificationsEnabled);
  const [morningAthkarTime, setMorningAthkarTime] = useState('07:00');
  const [eveningAthkarTime, setEveningAthkarTime] = useState('17:00');
  
  const colors = getThemeColors(isDarkMode);
  const typography = getTypography(selectedFontSize, selectedFontType);
  const spacing = getSpacing();
  const commonStyles = createCommonStyles(isDarkMode, selectedFontSize, selectedFontType);
  
  // تطبيق التغييرات على الإعدادات
  const applySettings = async () => {
    try {
      // تحديث الإعدادات في Redux
      dispatch({
        type: 'settings/updateSettings',
        payload: {
          darkMode: isDarkMode,
          fontSize: selectedFontSize,
          fontType: selectedFontType,
          notificationsEnabled: areNotificationsEnabled
        }
      });
      
      // حفظ الإعدادات في التخزين المحلي
      await StorageService.saveSettings({
        darkMode: isDarkMode,
        fontSize: selectedFontSize,
        fontType: selectedFontType,
        notificationsEnabled: areNotificationsEnabled,
        morningAthkarTime,
        eveningAthkarTime
      });
      
      // إعداد الإشعارات إذا كانت مفعلة
      if (areNotificationsEnabled) {
        const [morningHour, morningMinute] = morningAthkarTime.split(':').map(Number);
        const [eveningHour, eveningMinute] = eveningAthkarTime.split(':').map(Number);
        
        await NotificationService.cancelAllNotifications();
        await NotificationService.scheduleMorningAthkarNotification(morningHour, morningMinute);
        await NotificationService.scheduleEveningAthkarNotification(eveningHour, eveningMinute);
        await NotificationService.scheduleDailyVerseNotification(12, 0);
      } else {
        await NotificationService.cancelAllNotifications();
      }
      
      Alert.alert('تم', 'تم حفظ الإعدادات بنجاح');
    } catch (error) {
      console.error('خطأ في حفظ الإعدادات:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء حفظ الإعدادات');
    }
  };
  
  const resetSettings = async () => {
    Alert.alert(
      'إعادة ضبط الإعدادات',
      'هل أنت متأكد من رغبتك في إعادة ضبط جميع الإعدادات إلى الوضع الافتراضي؟',
      [
        {
          text: 'إلغاء',
          style: 'cancel'
        },
        {
          text: 'إعادة ضبط',
          onPress: async () => {
            setIsDarkMode(false);
            setSelectedFontSize('medium');
            setSelectedFontType('default');
            setAreNotificationsEnabled(true);
            setMorningAthkarTime('07:00');
            setEveningAthkarTime('17:00');
            
            // تطبيق الإعدادات الافتراضية
            await applySettings();
          }
        }
      ]
    );
  };
  
  const renderFontSizeSelector = () => (
    <View style={styles.optionGroup}>
      <Text style={[styles.optionTitle, { color: colors.text }]}>حجم الخط</Text>
      
      <View style={styles.fontSizeOptions}>
        <TouchableOpacity
          style={[
            styles.fontSizeOption,
            selectedFontSize === 'small' && { backgroundColor: colors.primary },
          ]}
          onPress={() => setSelectedFontSize('small')}
        >
          <Text
            style={[
              styles.fontSizeText,
              { fontSize: 14 },
              selectedFontSize === 'small' ? { color: '#ffffff' } : { color: colors.text }
            ]}
          >
            صغير
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.fontSizeOption,
            selectedFontSize === 'medium' && { backgroundColor: colors.primary },
          ]}
          onPress={() => setSelectedFontSize('medium')}
        >
          <Text
            style={[
              styles.fontSizeText,
              { fontSize: 16 },
              selectedFontSize === 'medium' ? { color: '#ffffff' } : { color: colors.text }
            ]}
          >
            متوسط
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.fontSizeOption,
            selectedFontSize === 'large' && { backgroundColor: colors.primary },
          ]}
          onPress={() => setSelectedFontSize('large')}
        >
          <Text
            style={[
              styles.fontSizeText,
              { fontSize: 18 },
              selectedFontSize === 'large' ? { color: '#ffffff' } : { color: colors.text }
            ]}
          >
            كبير
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
  
  const renderFontTypeSelector = () => (
    <View style={styles.optionGroup}>
      <Text style={[styles.optionTitle, { color: colors.text }]}>نوع الخط</Text>
      
      <View style={styles.fontTypeOptions}>
        <TouchableOpacity
          style={[
            styles.fontTypeOption,
            selectedFontType === 'default' && { backgroundColor: colors.primary },
          ]}
          onPress={() => setSelectedFontType('default')}
        >
          <Text
            style={[
              styles.fontTypeText,
              selectedFontType === 'default' ? { color: '#ffffff' } : { color: colors.text }
            ]}
          >
            الافتراضي
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.fontTypeOption,
            selectedFontType === 'uthmani' && { backgroundColor: colors.primary },
          ]}
          onPress={() => setSelectedFontType('uthmani')}
        >
          <Text
            style={[
              styles.fontTypeText,
              selectedFontType === 'uthmani' ? { color: '#ffffff' } : { color: colors.text }
            ]}
          >
            عثماني
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={[styles.screenTitle, { color: colors.text }]}>الإعدادات</Text>
        
        <Card style={styles.settingsCard}>
          <View style={styles.settingItem}>
            <View style={styles.settingLabelContainer}>
              <Ionicons name="moon" size={24} color={colors.text} style={styles.settingIcon} />
              <Text style={[styles.settingLabel, { color: colors.text }]}>الوضع الليلي</Text>
            </View>
            <Switch
              value={isDarkMode}
              onValueChange={setIsDarkMode}
              trackColor={{ false: '#e0e0e0', true: colors.primaryLight }}
              thumbColor={isDarkMode ? colors.primary : '#f5f5f5'}
            />
          </View>
          
          {renderFontSizeSelector()}
          {renderFontTypeSelector()}
          
          <View style={styles.settingItem}>
            <View style={styles.settingLabelContainer}>
              <Ionicons name="notifications" size={24} color={colors.text} style={styles.settingIcon} />
              <Text style={[styles.settingLabel, { color: colors.text }]}>الإشعارات</Text>
            </View>
            <Switch
              value={areNotificationsEnabled}
              onValueChange={setAreNotificationsEnabled}
              trackColor={{ false: '#e0e0e0', true: colors.primaryLight }}
              thumbColor={areNotificationsEnabled ? colors.primary : '#f5f5f5'}
            />
          </View>
          
          {areNotificationsEnabled && (
            <View style={styles.notificationTimesContainer}>
              <View style={styles.notificationTimeItem}>
                <Text style={[styles.notificationTimeLabel, { color: colors.text }]}>وقت أذكار الصباح</Text>
                <TouchableOpacity
                  style={[styles.timeSelector, { backgroundColor: colors.surface }]}
                  onPress={() => {
                    // هنا يمكن إضافة منتقي الوقت
                    // لكن في هذا المثال نستخدم قيمة ثابتة
                  }}
                >
                  <Text style={[styles.timeText, { color: colors.text }]}>{morningAthkarTime}</Text>
                </TouchableOpacity>
              </View>
              
              <View style={styles.notificationTimeItem}>
                <Text style={[styles.notificationTimeLabel, { color: colors.text }]}>وقت أذكار المساء</Text>
                <TouchableOpacity
                  style={[styles.timeSelector, { backgroundColor: colors.surface }]}
                  onPress={() => {
                    // هنا يمكن إضافة منتقي الوقت
                    // لكن في هذا المثال نستخدم قيمة ثابتة
                  }}
                >
                  <Text style={[styles.timeText, { color: colors.text }]}>{eveningAthkarTime}</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </Card>
        
        <Card style={styles.aboutCard}>
          <Text style={[styles.aboutTitle, { color: colors.text }]}>حول التطبيق</Text>
          <Text style={[styles.aboutText, { color: colors.textSecondary }]}>
            تطبيق إسلامي متكامل يوفر القرآن الكريم والأذكار والتفاسير والتلاوات الصوتية وغيرها من الميزات.
          </Text>
          <Text style={[styles.versionText, { color: colors.textSecondary }]}>الإصدار 1.0.0</Text>
        </Card>
        
        <View style={styles.buttonsContainer}>
          <TouchableOpacity
            style={[styles.applyButton, { backgroundColor: colors.primary }]}
            onPress={applySettings}
          >
            <Text style={styles.buttonText}>حفظ الإعدادات</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.resetButton, { borderColor: colors.error }]}
            onPress={resetSettings}
          >
            <Text style={[styles.resetButtonText, { color: colors.error }]}>إعادة ضبط</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  screenTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  settingsCard: {
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingIcon: {
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 16,
  },
  optionGroup: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  optionTitle: {
    fontSize: 16,
    marginBottom: 12,
  },
  fontSizeOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  fontSizeOption: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 4,
    marginHorizontal: 4,
    backgroundColor: '#f0f0f0',
  },
  fontSizeText: {
    fontWeight: 'bold',
  },
  fontTypeOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  fontTypeOption: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 4,
    marginHorizontal: 4,
    backgroundColor: '#f0f0f0',
  },
  fontTypeText: {
    fontWeight: 'bold',
  },
  notificationTimesContainer: {
    paddingVertical: 12,
  },
  notificationTimeItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  notificationTimeLabel: {
    fontSize: 14,
  },
  timeSelector: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  timeText: {
    fontSize: 14,
  },
  aboutCard: {
    marginBottom: 16,
  },
  aboutTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  aboutText: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 8,
  },
  versionText: {
    fontSize: 12,
    textAlign: 'center',
  },
  buttonsContainer: {
    marginBottom: 24,
  },
  applyButton: {
    paddingVertical: 12,
    borderRadius: 4,
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resetButton: {
    paddingVertical: 12,
    borderRadius: 4,
    alignItems: 'center',
    borderWidth: 1,
  },
  resetButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default SettingsScreen;
