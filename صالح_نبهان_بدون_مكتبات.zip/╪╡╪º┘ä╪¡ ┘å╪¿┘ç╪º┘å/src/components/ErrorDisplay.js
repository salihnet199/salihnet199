import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * مكون لعرض رسائل الخطأ بطريقة موحدة
 * @param {Object} props - خصائص المكون
 * @param {string} props.message - رسالة الخطأ
 * @param {Function} props.onRetry - دالة تُنفذ عند الضغط على زر إعادة المحاولة
 * @param {Object} props.style - أنماط إضافية للحاوية
 * @param {boolean} props.showRetry - عرض زر إعادة المحاولة
 */
const ErrorDisplay = ({ 
  message = 'حدث خطأ ما', 
  onRetry, 
  style,
  showRetry = true
}) => {
  return (
    <View style={[styles.container, style]}>
      <Ionicons name="alert-circle" size={48} color="#f44336" />
      <Text style={styles.message}>{message}</Text>
      {showRetry && onRetry && (
        <TouchableOpacity style={styles.retryButton} onPress={onRetry}>
          <Text style={styles.retryButtonText}>إعادة المحاولة</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  message: {
    marginTop: 16,
    fontSize: 16,
    textAlign: 'center',
    color: '#333333',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
  },
  retryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ErrorDisplay;
