import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * مكون زر مع أيقونة قابل للتخصيص
 * @param {Object} props - خصائص المكون
 * @param {string} props.name - اسم الأيقونة من مكتبة Ionicons
 * @param {string} props.size - حجم الأيقونة
 * @param {string} props.color - لون الأيقونة
 * @param {Function} props.onPress - دالة تُنفذ عند الضغط على الزر
 * @param {Object} props.style - أنماط إضافية للزر
 * @param {string} props.text - نص اختياري يظهر مع الأيقونة
 * @param {boolean} props.disabled - تعطيل التفاعل مع الزر
 */
const IconButton = ({ 
  name, 
  size = 24, 
  color = '#4CAF50', 
  onPress, 
  style, 
  text, 
  disabled = false 
}) => {
  return (
    <TouchableOpacity
      style={[styles.container, style]}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.7}
    >
      <Ionicons name={name} size={size} color={disabled ? '#cccccc' : color} />
      {text && <Text style={[styles.text, { color: disabled ? '#cccccc' : color }]}>{text}</Text>}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
  },
  text: {
    marginLeft: 8,
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default IconButton;
