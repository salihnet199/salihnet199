import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

/**
 * مكون بطاقة قابل للتخصيص
 * @param {Object} props - خصائص المكون
 * @param {React.ReactNode} props.children - المحتوى الداخلي للبطاقة
 * @param {Object} props.style - أنماط إضافية للبطاقة
 * @param {Function} props.onPress - دالة تُنفذ عند الضغط على البطاقة
 * @param {boolean} props.disabled - تعطيل التفاعل مع البطاقة
 */
const Card = ({ children, style, onPress, disabled = false }) => {
  if (onPress) {
    return (
      <TouchableOpacity
        style={[styles.card, style]}
        onPress={onPress}
        disabled={disabled}
        activeOpacity={0.7}
      >
        {children}
      </TouchableOpacity>
    );
  }
  
  return (
    <View style={[styles.card, style]}>
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 16,
    marginVertical: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
});

export default Card;
