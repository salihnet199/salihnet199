import React from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * مكون شريط بحث قابل للتخصيص
 * @param {Object} props - خصائص المكون
 * @param {string} props.placeholder - نص توضيحي يظهر عندما يكون حقل البحث فارغًا
 * @param {string} props.value - قيمة حقل البحث
 * @param {Function} props.onChangeText - دالة تُنفذ عند تغيير نص البحث
 * @param {Function} props.onSubmit - دالة تُنفذ عند إرسال البحث
 * @param {Object} props.style - أنماط إضافية للحاوية
 * @param {boolean} props.autoFocus - تركيز تلقائي على حقل البحث
 */
const SearchBar = ({ 
  placeholder = 'بحث...', 
  value, 
  onChangeText, 
  onSubmit, 
  style,
  autoFocus = false
}) => {
  return (
    <View style={[styles.container, style]}>
      <Ionicons name="search" size={20} color="#757575" style={styles.searchIcon} />
      <TextInput
        style={styles.input}
        placeholder={placeholder}
        value={value}
        onChangeText={onChangeText}
        onSubmitEditing={onSubmit}
        returnKeyType="search"
        autoFocus={autoFocus}
        placeholderTextColor="#9e9e9e"
      />
      {value ? (
        <TouchableOpacity onPress={() => onChangeText('')} style={styles.clearButton}>
          <Ionicons name="close-circle" size={20} color="#757575" />
        </TouchableOpacity>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    paddingHorizontal: 12,
    marginVertical: 8,
    height: 48,
  },
  searchIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#212121',
    textAlign: 'right',
  },
  clearButton: {
    padding: 4,
  },
});

export default SearchBar;
