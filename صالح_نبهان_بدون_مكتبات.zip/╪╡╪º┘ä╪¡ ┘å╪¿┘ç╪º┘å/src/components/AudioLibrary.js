import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList, Image } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import Card from './Card';
import IconButton from './IconButton';
import LoadingIndicator from './LoadingIndicator';
import SearchBar from './SearchBar';
import AudioPlayer from './AudioPlayer';
import { getThemeColors } from '../styles/colors';
import { getTypography } from '../styles/typography';
import { getSpacing } from '../styles/spacing';
import { createCommonStyles } from '../styles/common';

const AudioLibrary = ({ navigation }) => {
  const [reciters, setReciters] = useState([]);
  const [surahs, setSurahs] = useState([]);
  const [selectedReciter, setSelectedReciter] = useState(null);
  const [selectedSurah, setSelectedSurah] = useState(null);
  const [currentAudio, setCurrentAudio] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredReciters, setFilteredReciters] = useState([]);
  
  const { darkMode, fontSize } = useSelector(state => state.settings);
  
  const colors = getThemeColors(darkMode);
  const typography = getTypography(fontSize);
  const spacing = getSpacing();
  const commonStyles = createCommonStyles(darkMode, fontSize);
  
  // محاكاة تحميل القراء والسور
  useEffect(() => {
    setIsLoading(true);
    
    // محاكاة استدعاء API
    setTimeout(() => {
      // بيانات وهمية للقراء
      const dummyReciters = [
        { id: 1, name: 'عبد الباسط عبد الصمد', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
        { id: 2, name: 'محمود خليل الحصري', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
        { id: 3, name: 'محمد صديق المنشاوي', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
        { id: 4, name: 'ماهر المعيقلي', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
        { id: 5, name: 'سعد الغامدي', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
        { id: 6, name: 'عبد الرحمن السديس', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
        { id: 7, name: 'مشاري راشد العفاسي', style: 'مرتل', image: 'https://i.imgur.com/placeholder.jpg' },
      ];
      
      // بيانات وهمية للسور
      const dummySurahs = [
        { id: 1, name: 'الفاتحة', ayahs: 7, translation: 'The Opening' },
        { id: 2, name: 'البقرة', ayahs: 286, translation: 'The Cow' },
        { id: 3, name: 'آل عمران', ayahs: 200, translation: 'Family of Imran' },
        { id: 4, name: 'النساء', ayahs: 176, translation: 'The Women' },
        { id: 5, name: 'المائدة', ayahs: 120, translation: 'The Table Spread' },
        { id: 6, name: 'الأنعام', ayahs: 165, translation: 'The Cattle' },
        { id: 7, name: 'الأعراف', ayahs: 206, translation: 'The Heights' },
      ];
      
      setReciters(dummyReciters);
      setFilteredReciters(dummyReciters);
      setSurahs(dummySurahs);
      setIsLoading(false);
    }, 1000);
  }, []);
  
  // تصفية القراء حسب البحث
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredReciters(reciters);
    } else {
      const filtered = reciters.filter(
        reciter => reciter.name.includes(searchQuery)
      );
      setFilteredReciters(filtered);
    }
  }, [searchQuery, reciters]);
  
  const handleSearch = (text) => {
    setSearchQuery(text);
  };
  
  const handleReciterSelect = (reciter) => {
    setSelectedReciter(reciter);
  };
  
  const handleSurahSelect = (surah) => {
    setSelectedSurah(surah);
    
    // محاكاة تحميل الصوت
    setCurrentAudio({
      audioUrl: `https://audio.example.com/reciter/${selectedReciter?.id}/surah/${surah.id}.mp3`,
      ayahData: {
        surah_name: surah.name,
        number: 1,
      }
    });
  };
  
  const renderReciterItem = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.reciterItem,
        selectedReciter && selectedReciter.id === item.id && { backgroundColor: colors.primaryLight }
      ]}
      onPress={() => handleReciterSelect(item)}
    >
      <View style={styles.reciterImageContainer}>
        <View style={styles.reciterImagePlaceholder}>
          <Ionicons name="person" size={24} color="#ffffff" />
        </View>
      </View>
      <View style={styles.reciterInfo}>
        <Text style={[styles.reciterName, { color: colors.text }]}>{item.name}</Text>
        <Text style={[styles.reciterStyle, { color: colors.textSecondary }]}>{item.style}</Text>
      </View>
      {selectedReciter && selectedReciter.id === item.id && (
        <Ionicons name="checkmark-circle" size={24} color={colors.primary} />
      )}
    </TouchableOpacity>
  );
  
  const renderSurahItem = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.surahItem,
        selectedSurah && selectedSurah.id === item.id && { backgroundColor: colors.primaryLight }
      ]}
      onPress={() => handleSurahSelect(item)}
      disabled={!selectedReciter}
    >
      <View style={styles.surahNumber}>
        <Text style={styles.surahNumberText}>{item.id}</Text>
      </View>
      <View style={styles.surahInfo}>
        <Text style={[styles.surahName, { color: colors.text }]}>{item.name}</Text>
        <Text style={[styles.surahDetails, { color: colors.textSecondary }]}>
          {item.ayahs} آية - {item.translation}
        </Text>
      </View>
      {selectedSurah && selectedSurah.id === item.id && (
        <Ionicons name="musical-notes" size={24} color={colors.primary} />
      )}
    </TouchableOpacity>
  );
  
  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <LoadingIndicator text="جاري تحميل مكتبة التلاوات..." />
      </View>
    );
  }
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>التلاوات الصوتية</Text>
        
        <View style={styles.searchContainer}>
          <SearchBar
            placeholder="بحث عن قارئ..."
            value={searchQuery}
            onChangeText={handleSearch}
            onSubmit={() => {}}
          />
        </View>
      </View>
      
      <View style={styles.contentContainer}>
        <View style={styles.recitersList}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>القراء</Text>
          {filteredReciters.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                لا توجد نتائج تطابق بحثك
              </Text>
            </View>
          ) : (
            <FlatList
              data={filteredReciters}
              renderItem={renderReciterItem}
              keyExtractor={item => item.id.toString()}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.recitersListContent}
            />
          )}
        </View>
        
        <View style={styles.surahsList}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            {selectedReciter ? `سور القرآن - ${selectedReciter.name}` : 'اختر قارئاً أولاً'}
          </Text>
          {!selectedReciter ? (
            <View style={styles.emptyContainer}>
              <Ionicons name="person" size={48} color={colors.textSecondary} />
              <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                الرجاء اختيار قارئ من القائمة
              </Text>
            </View>
          ) : (
            <FlatList
              data={surahs}
              renderItem={renderSurahItem}
              keyExtractor={item => item.id.toString()}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.surahsListContent}
            />
          )}
        </View>
      </View>
      
      {currentAudio && (
        <View style={styles.playerContainer}>
          <AudioPlayer
            audioUrl={currentAudio.audioUrl}
            ayahData={currentAudio.ayahData}
            autoPlay={true}
            onPlaybackStatusChange={(status) => console.log('حالة التشغيل:', status)}
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  searchContainer: {
    marginBottom: 8,
  },
  contentContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  recitersList: {
    flex: 1,
    marginRight: 8,
  },
  surahsList: {
    flex: 1,
    marginLeft: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  recitersListContent: {
    paddingBottom: 16,
  },
  surahsListContent: {
    paddingBottom: 16,
  },
  reciterItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: '#f5f5f5',
  },
  reciterImageContainer: {
    marginRight: 12,
  },
  reciterImagePlaceholder: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#9e9e9e',
    justifyContent: 'center',
    alignItems: 'center',
  },
  reciterInfo: {
    flex: 1,
  },
  reciterName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  reciterStyle: {
    fontSize: 14,
  },
  surahItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: '#f5f5f5',
  },
  surahNumber: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  surahNumberText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  surahInfo: {
    flex: 1,
  },
  surahName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  surahDetails: {
    fontSize: 14,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 8,
  },
  playerContainer: {
    marginTop: 16,
  },
});

export default AudioLibrary;
