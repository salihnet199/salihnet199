import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { Ionicons } from '@expo/vector-icons';
import Card from './Card';
import IconButton from './IconButton';
import LoadingIndicator from './LoadingIndicator';
import SearchBar from './SearchBar';
import AyahRenderer from './AyahRenderer';
import { getThemeColors } from '../styles/colors';
import { getTypography } from '../styles/typography';
import { getSpacing } from '../styles/spacing';
import { createCommonStyles } from '../styles/common';

const TafseerView = ({ navigation, surahNumber = 1, ayahNumber = 1 }) => {
  const [tafseerList, setTafseerList] = useState([]);
  const [selectedTafseer, setSelectedTafseer] = useState(null);
  const [ayahData, setAyahData] = useState(null);
  const [tafseerContent, setTafseerContent] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  
  const { darkMode, fontSize } = useSelector(state => state.settings);
  
  const colors = getThemeColors(darkMode);
  const typography = getTypography(fontSize);
  const spacing = getSpacing();
  const commonStyles = createCommonStyles(darkMode, fontSize);
  
  // محاكاة تحميل قائمة التفاسير
  useEffect(() => {
    setIsLoading(true);
    
    // محاكاة استدعاء API
    setTimeout(() => {
      // بيانات وهمية للتفاسير
      const dummyTafseerList = [
        { id: 1, name: 'تفسير ابن كثير', author: 'ابن كثير', language: 'ar' },
        { id: 2, name: 'تفسير السعدي', author: 'عبد الرحمن السعدي', language: 'ar' },
        { id: 3, name: 'تفسير الطبري', author: 'ابن جرير الطبري', language: 'ar' },
        { id: 4, name: 'تفسير القرطبي', author: 'القرطبي', language: 'ar' },
        { id: 5, name: 'تفسير البغوي', author: 'البغوي', language: 'ar' },
      ];
      
      setTafseerList(dummyTafseerList);
      setSelectedTafseer(dummyTafseerList[0]);
      setIsLoading(false);
      
      // محاكاة بيانات الآية
      const dummyAyah = {
        surah_name: 'الفاتحة',
        surah_number: 1,
        number: ayahNumber,
        text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
        translation: 'In the name of Allah, the Entirely Merciful, the Especially Merciful',
      };
      
      setAyahData(dummyAyah);
      
      // محاكاة محتوى التفسير
      const dummyTafseerContent = `
        قال ابن كثير في تفسير "بسم الله الرحمن الرحيم":
        
        البسملة آية من كتاب الله تعالى، وهي جزء من آيات سورة النمل، وهي بعض آية من الفاتحة على أحد القولين، وهي آية مستقلة في أول كل سورة عند من يقول بذلك من العلماء.
        
        وقد اختلف العلماء في البسملة هل هي آية من الفاتحة أم لا؟ على قولين مشهورين، وهما روايتان عن الإمام مالك، والصحيح أنها آية منها، وهو مذهب الشافعي.
        
        وقوله: "الرحمن الرحيم" اسمان مشتقان من الرحمة على وجه المبالغة، و"الرحمن" أشد مبالغة من "الرحيم"، ولهذا قال العلماء: "الرحمن" الذي تعم رحمته جميع الخلائق في الدنيا، و"الرحيم" بالمؤمنين.
        
        وقال بعض النحاة: "الرحمن" هو الذي تكون منه الرحمة، و"الرحيم" هو الراحم، فالأول دال على الصفة القائمة به سبحانه، والثاني دال على تعلقها بالمرحوم.
      `;
      
      setTafseerContent(dummyTafseerContent);
    }, 1000);
  }, [surahNumber, ayahNumber]);
  
  const handleTafseerChange = (tafseer) => {
    setSelectedTafseer(tafseer);
    setIsLoading(true);
    
    // محاكاة تحميل التفسير الجديد
    setTimeout(() => {
      // محاكاة محتوى التفسير الجديد
      const newTafseerContent = `
        قال ${tafseer.author} في تفسير "بسم الله الرحمن الرحيم":
        
        ${tafseer.id === 1 ? `
        البسملة آية من كتاب الله تعالى، وهي جزء من آيات سورة النمل، وهي بعض آية من الفاتحة على أحد القولين، وهي آية مستقلة في أول كل سورة عند من يقول بذلك من العلماء.
        
        وقد اختلف العلماء في البسملة هل هي آية من الفاتحة أم لا؟ على قولين مشهورين، وهما روايتان عن الإمام مالك، والصحيح أنها آية منها، وهو مذهب الشافعي.
        ` : tafseer.id === 2 ? `
        البسملة هي افتتاح كل أمر ذي بال، وهي مفتاح كل خير، وهي تبرك واستعانة بالله تعالى.
        
        والله سبحانه هو الإله الحق المستحق للعبادة، والرحمن الرحيم هما اسمان من أسماء الله الحسنى، يدلان على صفة الرحمة.
        ` : tafseer.id === 3 ? `
        قال أبو جعفر: القول في تأويل قوله: "بسم الله الرحمن الرحيم".
        
        اختلف أهل التأويل في تأويل ذلك، فقال بعضهم: معناه: ابتدائي بسم الله. وقال آخرون: معناه: ابتدأت بسم الله.
        
        والصواب من القول في ذلك عندنا أن يقال: إن الله جل ثناؤه علم عباده أن يفتتحوا أمورهم بذكر اسمه.
        ` : tafseer.id === 4 ? `
        قال القرطبي: البسملة آية من كتاب الله، نزلت مع كل سورة، وهي من القرآن بلا خلاف.
        
        واختلف العلماء: هل هي آية من كل سورة، أو آية من القرآن أنزلت للفصل بين السور، أو هي آية من الفاتحة فقط؟
        
        والصحيح أنها آية من الفاتحة، وآية مستقلة نزلت للفصل بين السور.
        ` : `
        قال البغوي: البسملة مشروعة في أول كل عمل، وهي مباركة حيثما ذكرت.
        
        وقد اختلف العلماء في كونها آية من الفاتحة، والصحيح أنها آية منها، وهو قول الشافعي.
        
        والله سبحانه هو المعبود بحق، والرحمن الرحيم وصفان مشتقان من الرحمة.
        `}
      `;
      
      setTafseerContent(newTafseerContent);
      setIsLoading(false);
    }, 500);
  };
  
  const renderTafseerSelector = () => (
    <View style={styles.tafseerSelector}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {tafseerList.map(tafseer => (
          <TouchableOpacity
            key={tafseer.id}
            style={[
              styles.tafseerButton,
              selectedTafseer && selectedTafseer.id === tafseer.id && { backgroundColor: colors.primary }
            ]}
            onPress={() => handleTafseerChange(tafseer)}
          >
            <Text
              style={[
                styles.tafseerButtonText,
                selectedTafseer && selectedTafseer.id === tafseer.id ? { color: '#ffffff' } : { color: colors.text }
              ]}
            >
              {tafseer.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
  
  if (isLoading && !ayahData) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <LoadingIndicator text="جاري تحميل التفسير..." />
      </View>
    );
  }
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>التفسير</Text>
      </View>
      
      {ayahData && (
        <AyahRenderer
          ayah={ayahData}
          onPlayAudio={() => console.log('تشغيل الصوت')}
          onShowTafseer={() => {}}
          onAddBookmark={() => console.log('إضافة إلى المفضلة')}
          style={styles.ayahRenderer}
        />
      )}
      
      {renderTafseerSelector()}
      
      <Card style={styles.tafseerCard}>
        <View style={styles.tafseerHeader}>
          <Text style={[styles.tafseerTitle, { color: colors.text }]}>
            {selectedTafseer ? selectedTafseer.name : 'التفسير'}
          </Text>
          {selectedTafseer && (
            <Text style={[styles.tafseerAuthor, { color: colors.textSecondary }]}>
              للإمام: {selectedTafseer.author}
            </Text>
          )}
        </View>
        
        {isLoading ? (
          <LoadingIndicator size="small" text="جاري تحميل التفسير..." />
        ) : (
          <ScrollView style={styles.tafseerContent}>
            <Text style={[styles.tafseerText, { color: colors.text }]}>
              {tafseerContent}
            </Text>
          </ScrollView>
        )}
      </Card>
      
      <View style={styles.navigationControls}>
        <TouchableOpacity 
          style={[styles.navButton, { backgroundColor: colors.primary }]}
          onPress={() => {
            if (ayahNumber > 1) {
              navigation.replace('TafseerScreen', { surahNumber, ayahNumber: ayahNumber - 1 });
            } else if (surahNumber > 1) {
              // هنا يجب الحصول على عدد آيات السورة السابقة
              navigation.replace('TafseerScreen', { surahNumber: surahNumber - 1, ayahNumber: 7 });
            }
          }}
          disabled={surahNumber === 1 && ayahNumber === 1}
        >
          <Ionicons name="chevron-back" size={24} color="#ffffff" />
          <Text style={styles.navButtonText}>الآية السابقة</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.navButton, { backgroundColor: colors.primary }]}
          onPress={() => {
            // هنا يجب التحقق من عدد آيات السورة الحالية
            if (ayahNumber < 7) {
              navigation.replace('TafseerScreen', { surahNumber, ayahNumber: ayahNumber + 1 });
            } else if (surahNumber < 114) {
              navigation.replace('TafseerScreen', { surahNumber: surahNumber + 1, ayahNumber: 1 });
            }
          }}
          disabled={surahNumber === 114 && ayahNumber === 6}
        >
          <Text style={styles.navButtonText}>الآية التالية</Text>
          <Ionicons name="chevron-forward" size={24} color="#ffffff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  ayahRenderer: {
    marginBottom: 16,
  },
  tafseerSelector: {
    marginBottom: 16,
  },
  tafseerButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: '#f0f0f0',
  },
  tafseerButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  tafseerCard: {
    flex: 1,
    marginBottom: 80,
  },
  tafseerHeader: {
    marginBottom: 16,
  },
  tafseerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  tafseerAuthor: {
    fontSize: 14,
  },
  tafseerContent: {
    flex: 1,
  },
  tafseerText: {
    fontSize: 16,
    lineHeight: 28,
    textAlign: 'right',
  },
  navigationControls: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  navButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  navButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    marginHorizontal: 4,
  },
});

export default TafseerView;
