import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, ScrollView } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { fetchTafseerData, setCurrentTafseer } from '../redux/slices/tafseerSlice';

const TafseerScreen = () => {
  const dispatch = useDispatch();
  const { tafseerList, currentTafseer, currentTafseerData, loading, error } = useSelector(state => state.tafseer);
  const { darkMode, fontSize } = useSelector(state => state.settings);
  
  const [surahNumber, setSurahNumber] = useState(1);
  const [ayahNumber, setAyahNumber] = useState(1);
  
  // تحديد الألوان بناءً على وضع الظلام
  const backgroundColor = darkMode ? '#121212' : '#f5f5f5';
  const textColor = darkMode ? '#ffffff' : '#000000';
  const cardColor = darkMode ? '#1e1e1e' : '#ffffff';
  
  // تحديد حجم الخط بناءً على إعدادات المستخدم
  const getFontSize = (baseSize) => {
    switch(fontSize) {
      case 'small': return baseSize - 2;
      case 'large': return baseSize + 2;
      default: return baseSize;
    }
  };
  
  useEffect(() => {
    // استدعاء بيانات التفسير عند تغيير السورة أو الآية أو التفسير المحدد
    dispatch(fetchTafseerData({ surahNumber, ayahNumber, tafseerID: currentTafseer }));
  }, [dispatch, surahNumber, ayahNumber, currentTafseer]);
  
  // الحصول على بيانات التفسير الحالية
  const getCurrentTafseerData = () => {
    const key = `${surahNumber}:${ayahNumber}`;
    return currentTafseerData[key] || null;
  };
  
  // الحصول على اسم التفسير الحالي
  const getCurrentTafseerName = () => {
    const tafseer = tafseerList.find(t => t.id === currentTafseer);
    return tafseer ? tafseer.name : '';
  };
  
  // عرض قائمة التفاسير المتاحة
  const renderTafseerSelector = () => (
    <ScrollView 
      horizontal 
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.tafseerSelectorContainer}
    >
      {tafseerList.map(tafseer => (
        <TouchableOpacity
          key={tafseer.id}
          style={[
            styles.tafseerSelectorItem,
            currentTafseer === tafseer.id && styles.activeTafseer
          ]}
          onPress={() => dispatch(setCurrentTafseer(tafseer.id))}
        >
          <Text 
            style={[
              styles.tafseerSelectorText,
              currentTafseer === tafseer.id && styles.activeTafseerText,
              { fontSize: getFontSize(14) }
            ]}
          >
            {tafseer.name}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
  
  // عرض أدوات اختيار السورة والآية
  const renderSurahAyahSelector = () => (
    <View style={styles.selectorContainer}>
      <View style={styles.selectorGroup}>
        <Text style={[styles.selectorLabel, { color: textColor }]}>السورة:</Text>
        <View style={styles.selectorControls}>
          <TouchableOpacity 
            style={styles.selectorButton}
            onPress={() => setSurahNumber(prev => Math.min(114, prev + 1))}
          >
            <Text style={styles.selectorButtonText}>+</Text>
          </TouchableOpacity>
          <Text style={[styles.selectorValue, { color: textColor }]}>{surahNumber}</Text>
          <TouchableOpacity 
            style={styles.selectorButton}
            onPress={() => setSurahNumber(prev => Math.max(1, prev - 1))}
          >
            <Text style={styles.selectorButtonText}>-</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.selectorGroup}>
        <Text style={[styles.selectorLabel, { color: textColor }]}>الآية:</Text>
        <View style={styles.selectorControls}>
          <TouchableOpacity 
            style={styles.selectorButton}
            onPress={() => setAyahNumber(prev => prev + 1)}
          >
            <Text style={styles.selectorButtonText}>+</Text>
          </TouchableOpacity>
          <Text style={[styles.selectorValue, { color: textColor }]}>{ayahNumber}</Text>
          <TouchableOpacity 
            style={styles.selectorButton}
            onPress={() => setAyahNumber(prev => Math.max(1, prev - 1))}
          >
            <Text style={styles.selectorButtonText}>-</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
  
  // عرض محتوى التفسير
  const renderTafseerContent = () => {
    const tafseerData = getCurrentTafseerData();
    
    if (loading) {
      return (
        <View style={styles.contentContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={[styles.loadingText, { color: textColor }]}>جاري تحميل التفسير...</Text>
        </View>
      );
    }
    
    if (error) {
      return (
        <View style={styles.contentContainer}>
          <Text style={[styles.errorText, { color: textColor }]}>حدث خطأ أثناء تحميل التفسير</Text>
          <TouchableOpacity 
            style={styles.retryButton}
            onPress={() => dispatch(fetchTafseerData({ surahNumber, ayahNumber, tafseerID: currentTafseer }))}
          >
            <Text style={styles.retryButtonText}>إعادة المحاولة</Text>
          </TouchableOpacity>
        </View>
      );
    }
    
    if (!tafseerData) {
      return (
        <View style={styles.contentContainer}>
          <Text style={[styles.emptyText, { color: textColor }]}>لا يوجد تفسير متاح لهذه الآية</Text>
        </View>
      );
    }
    
    return (
      <ScrollView style={styles.tafseerContentContainer}>
        <View style={[styles.ayahCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.ayahText, { color: textColor, fontSize: getFontSize(20) }]}>
            {tafseerData.text}
          </Text>
          <Text style={[styles.ayahReference, { color: textColor }]}>
            سورة {tafseerData.surah_name} - الآية {ayahNumber}
          </Text>
        </View>
        
        <View style={[styles.tafseerCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.tafseerTitle, { color: textColor }]}>
            {getCurrentTafseerName()}
          </Text>
          <Text style={[styles.tafseerText, { color: textColor, fontSize: getFontSize(16) }]}>
            {tafseerData.text}
          </Text>
        </View>
      </ScrollView>
    );
  };
  
  return (
    <View style={[styles.container, { backgroundColor }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: textColor }]}>التفسير</Text>
      </View>
      
      {renderTafseerSelector()}
      {renderSurahAyahSelector()}
      {renderTafseerContent()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginVertical: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  tafseerSelectorContainer: {
    paddingBottom: 8,
    marginBottom: 16,
  },
  tafseerSelectorItem: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginHorizontal: 4,
    borderRadius: 16,
    backgroundColor: '#e0e0e0',
  },
  activeTafseer: {
    backgroundColor: '#4CAF50',
  },
  tafseerSelectorText: {
    color: '#000000',
  },
  activeTafseerText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  selectorContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  selectorGroup: {
    alignItems: 'center',
  },
  selectorLabel: {
    fontSize: 16,
    marginBottom: 8,
  },
  selectorControls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectorButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectorButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  selectorValue: {
    fontSize: 18,
    fontWeight: 'bold',
    marginHorizontal: 12,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    textAlign: 'center',
  },
  errorText: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
  },
  retryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  emptyText: {
    fontSize: 16,
    textAlign: 'center',
  },
  tafseerContentContainer: {
    flex: 1,
  },
  ayahCard: {
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  ayahText: {
    textAlign: 'center',
    lineHeight: 36,
    marginBottom: 12,
  },
  ayahReference: {
    textAlign: 'center',
    fontSize: 14,
    fontStyle: 'italic',
  },
  tafseerCard: {
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  tafseerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'center',
  },
  tafseerText: {
    textAlign: 'right',
    lineHeight: 28,
  },
});

export default TafseerScreen;
