import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { fetchQuranData, setCurrentPage } from '../redux/slices/quranSlice';

const QuranScreen = () => {
  const dispatch = useDispatch();
  const { surahs, loading, error, currentPage } = useSelector(state => state.quran);
  const { darkMode, fontSize } = useSelector(state => state.settings);
  
  const [viewMode, setViewMode] = useState('surahs'); // surahs, pages, bookmarks
  
  // تحديد الألوان بناءً على وضع الظلام
  const backgroundColor = darkMode ? '#121212' : '#f5f5f5';
  const textColor = darkMode ? '#ffffff' : '#000000';
  const cardColor = darkMode ? '#1e1e1e' : '#ffffff';
  
  // تحديد حجم الخط بناءً على إعدادات المستخدم
  const getFontSize = (baseSize) => {
    switch(fontSize) {
      case 'small': return baseSize - 2;
      case 'large': return baseSize + 2;
      default: return baseSize;
    }
  };
  
  useEffect(() => {
    // استدعاء بيانات القرآن عند تحميل الشاشة
    dispatch(fetchQuranData());
  }, [dispatch]);
  
  // عرض مؤشر التحميل أثناء جلب البيانات
  if (loading && surahs.length === 0) {
    return (
      <View style={[styles.container, { backgroundColor, justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text style={[styles.loadingText, { color: textColor }]}>جاري تحميل بيانات القرآن الكريم...</Text>
      </View>
    );
  }
  
  // عرض رسالة الخطأ في حالة فشل جلب البيانات
  if (error && surahs.length === 0) {
    return (
      <View style={[styles.container, { backgroundColor, justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={[styles.errorText, { color: textColor }]}>حدث خطأ أثناء تحميل البيانات</Text>
        <TouchableOpacity 
          style={styles.retryButton}
          onPress={() => dispatch(fetchQuranData())}
        >
          <Text style={styles.retryButtonText}>إعادة المحاولة</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  // عرض قائمة السور
  const renderSurahItem = ({ item }) => (
    <TouchableOpacity 
      style={[styles.surahCard, { backgroundColor: cardColor }]}
      onPress={() => {
        // الانتقال إلى صفحة السورة
        dispatch(setCurrentPage(item.pages[0]));
        setViewMode('pages');
      }}
    >
      <View style={styles.surahNumberContainer}>
        <Text style={styles.surahNumber}>{item.id}</Text>
      </View>
      <View style={styles.surahInfoContainer}>
        <Text style={[styles.surahName, { color: textColor, fontSize: getFontSize(18) }]}>{item.name_arabic}</Text>
        <Text style={[styles.surahDetails, { color: textColor, fontSize: getFontSize(14) }]}>
          {item.revelation_place === 'makkah' ? 'مكية' : 'مدنية'} • {item.verses_count} آية
        </Text>
      </View>
      <Text style={[styles.surahNameArabic, { color: textColor, fontSize: getFontSize(22) }]}>{item.name_arabic}</Text>
    </TouchableOpacity>
  );
  
  // عرض قائمة الصفحات
  const renderPageView = () => {
    // هذا مجرد عرض مبسط للصفحات، سيتم تطويره لاحقًا
    const pages = Array.from({ length: 604 }, (_, i) => i + 1);
    
    return (
      <View style={[styles.pagesContainer, { backgroundColor }]}>
        <View style={styles.pageHeader}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setViewMode('surahs')}
          >
            <Text style={[styles.backButtonText, { color: textColor }]}>العودة للسور</Text>
          </TouchableOpacity>
          <Text style={[styles.pageTitle, { color: textColor }]}>الصفحات</Text>
        </View>
        
        <FlatList
          data={pages}
          keyExtractor={item => item.toString()}
          numColumns={3}
          renderItem={({ item }) => (
            <TouchableOpacity 
              style={[styles.pageCard, { backgroundColor: cardColor, borderColor: item === currentPage ? '#4CAF50' : 'transparent' }]}
              onPress={() => dispatch(setCurrentPage(item))}
            >
              <Text style={[styles.pageNumber, { color: textColor }]}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
    );
  };
  
  return (
    <View style={[styles.container, { backgroundColor }]}>
      {viewMode === 'surahs' ? (
        <>
          <View style={styles.header}>
            <Text style={[styles.title, { color: textColor }]}>القرآن الكريم</Text>
          </View>
          
          <View style={styles.viewModeContainer}>
            <TouchableOpacity 
              style={[styles.viewModeButton, viewMode === 'surahs' && styles.activeViewMode]}
              onPress={() => setViewMode('surahs')}
            >
              <Text style={[styles.viewModeText, viewMode === 'surahs' && styles.activeViewModeText]}>السور</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.viewModeButton, viewMode === 'pages' && styles.activeViewMode]}
              onPress={() => setViewMode('pages')}
            >
              <Text style={[styles.viewModeText, viewMode === 'pages' && styles.activeViewModeText]}>الصفحات</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.viewModeButton, viewMode === 'bookmarks' && styles.activeViewMode]}
              onPress={() => setViewMode('bookmarks')}
            >
              <Text style={[styles.viewModeText, viewMode === 'bookmarks' && styles.activeViewModeText]}>العلامات</Text>
            </TouchableOpacity>
          </View>
          
          <FlatList
            data={surahs}
            keyExtractor={item => item.id.toString()}
            renderItem={renderSurahItem}
            contentContainerStyle={styles.surahList}
          />
        </>
      ) : viewMode === 'pages' ? (
        renderPageView()
      ) : (
        <View style={[styles.container, { backgroundColor, justifyContent: 'center', alignItems: 'center' }]}>
          <Text style={[styles.title, { color: textColor }]}>العلامات المرجعية</Text>
          <Text style={[styles.emptyText, { color: textColor }]}>لا توجد علامات مرجعية حتى الآن</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginVertical: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    textAlign: 'center',
  },
  errorText: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
  },
  retryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  viewModeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
    borderRadius: 8,
    overflow: 'hidden',
  },
  viewModeButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    backgroundColor: '#e0e0e0',
  },
  activeViewMode: {
    backgroundColor: '#4CAF50',
  },
  viewModeText: {
    fontSize: 16,
    color: '#000000',
  },
  activeViewModeText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  surahList: {
    paddingBottom: 16,
  },
  surahCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 8,
    marginBottom: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  surahNumberContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  surahNumber: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  surahInfoContainer: {
    flex: 1,
  },
  surahName: {
    fontWeight: 'bold',
    textAlign: 'right',
  },
  surahDetails: {
    textAlign: 'right',
  },
  surahNameArabic: {
    fontWeight: 'bold',
    marginLeft: 8,
  },
  pagesContainer: {
    flex: 1,
  },
  pageHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    fontSize: 16,
  },
  pageTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  pageCard: {
    flex: 1,
    margin: 4,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
  },
  pageNumber: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  emptyText: {
    fontSize: 16,
    marginTop: 16,
  },
});

export default QuranScreen;
