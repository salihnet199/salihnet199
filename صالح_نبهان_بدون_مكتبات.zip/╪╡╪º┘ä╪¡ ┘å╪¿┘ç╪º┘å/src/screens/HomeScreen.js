import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useSelector } from 'react-redux';

const HomeScreen = () => {
  // استخدام حالة الإعدادات من Redux
  const { darkMode } = useSelector(state => state.settings);
  
  // تحديد الألوان بناءً على وضع الظلام
  const backgroundColor = darkMode ? '#121212' : '#f5f5f5';
  const textColor = darkMode ? '#ffffff' : '#000000';
  const cardColor = darkMode ? '#1e1e1e' : '#ffffff';
  
  return (
    <ScrollView style={[styles.container, { backgroundColor }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: textColor }]}>بسم الله الرحمن الرحيم</Text>
        <Text style={[styles.subtitle, { color: textColor }]}>تطبيق إسلامي متكامل</Text>
      </View>
      
      <View style={styles.featuresGrid}>
        <TouchableOpacity style={[styles.featureCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.featureTitle, { color: textColor }]}>القرآن الكريم</Text>
          <Text style={[styles.featureDescription, { color: textColor }]}>قراءة القرآن الكريم بتصميم المصحف</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.featureCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.featureTitle, { color: textColor }]}>الأذكار اليومية</Text>
          <Text style={[styles.featureDescription, { color: textColor }]}>أذكار الصباح والمساء وأذكار متنوعة</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.featureCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.featureTitle, { color: textColor }]}>التفسير</Text>
          <Text style={[styles.featureDescription, { color: textColor }]}>تفاسير متعددة للقرآن الكريم</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.featureCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.featureTitle, { color: textColor }]}>التلاوات الصوتية</Text>
          <Text style={[styles.featureDescription, { color: textColor }]}>استماع للقرآن بأصوات مختلفة</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.featureCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.featureTitle, { color: textColor }]}>البحث</Text>
          <Text style={[styles.featureDescription, { color: textColor }]}>البحث في القرآن الكريم</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.featureCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.featureTitle, { color: textColor }]}>الإحصائيات</Text>
          <Text style={[styles.featureDescription, { color: textColor }]}>تتبع تقدمك في القراءة والأذكار</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.lastReadSection}>
        <Text style={[styles.sectionTitle, { color: textColor }]}>آخر قراءة</Text>
        <TouchableOpacity style={[styles.lastReadCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.lastReadTitle, { color: textColor }]}>سورة البقرة</Text>
          <Text style={[styles.lastReadPage, { color: textColor }]}>الصفحة: 5</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.dailySection}>
        <Text style={[styles.sectionTitle, { color: textColor }]}>ورد اليوم</Text>
        <TouchableOpacity style={[styles.dailyCard, { backgroundColor: cardColor }]}>
          <Text style={[styles.dailyTitle, { color: textColor }]}>أذكار الصباح</Text>
          <Text style={[styles.dailyStatus, { color: textColor }]}>لم تكتمل بعد</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginVertical: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 16,
    textAlign: 'center',
  },
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  featureCard: {
    width: '48%',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  featureTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'right',
  },
  featureDescription: {
    fontSize: 14,
    textAlign: 'right',
  },
  lastReadSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'right',
  },
  lastReadCard: {
    padding: 16,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  lastReadTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'right',
  },
  lastReadPage: {
    fontSize: 14,
    textAlign: 'right',
  },
  dailySection: {
    marginBottom: 20,
  },
  dailyCard: {
    padding: 16,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  dailyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'right',
  },
  dailyStatus: {
    fontSize: 14,
    textAlign: 'right',
  },
});

export default HomeScreen;
