import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, Switch } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { fetchAthkarData, setCurrentCategory, incrementCounter, resetCounter } from '../redux/slices/athkarSlice';

const AthkarScreen = () => {
  const dispatch = useDispatch();
  const { morningAthkar, eveningAthkar, otherAthkar, loading, error, currentCategory, counter } = useSelector(state => state.athkar);
  const { darkMode, fontSize } = useSelector(state => state.settings);
  
  const [category, setCategory] = useState('morning'); // morning, evening, other
  
  // تحديد الألوان بناءً على وضع الظلام
  const backgroundColor = darkMode ? '#121212' : '#f5f5f5';
  const textColor = darkMode ? '#ffffff' : '#000000';
  const cardColor = darkMode ? '#1e1e1e' : '#ffffff';
  
  // تحديد حجم الخط بناءً على إعدادات المستخدم
  const getFontSize = (baseSize) => {
    switch(fontSize) {
      case 'small': return baseSize - 2;
      case 'large': return baseSize + 2;
      default: return baseSize;
    }
  };
  
  useEffect(() => {
    // استدعاء بيانات الأذكار عند تحميل الشاشة
    dispatch(fetchAthkarData(category));
    dispatch(setCurrentCategory(category));
  }, [dispatch, category]);
  
  // الحصول على بيانات الأذكار الحالية بناءً على الفئة المحددة
  const getCurrentAthkar = () => {
    switch(category) {
      case 'morning': return morningAthkar;
      case 'evening': return eveningAthkar;
      default: return otherAthkar;
    }
  };
  
  // عرض مؤشر التحميل أثناء جلب البيانات
  if (loading && getCurrentAthkar().length === 0) {
    return (
      <View style={[styles.container, { backgroundColor, justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text style={[styles.loadingText, { color: textColor }]}>جاري تحميل بيانات الأذكار...</Text>
      </View>
    );
  }
  
  // عرض رسالة الخطأ في حالة فشل جلب البيانات
  if (error && getCurrentAthkar().length === 0) {
    return (
      <View style={[styles.container, { backgroundColor, justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={[styles.errorText, { color: textColor }]}>حدث خطأ أثناء تحميل البيانات</Text>
        <TouchableOpacity 
          style={styles.retryButton}
          onPress={() => dispatch(fetchAthkarData(category))}
        >
          <Text style={styles.retryButtonText}>إعادة المحاولة</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  // عرض عنصر الذكر
  const renderAthkarItem = ({ item }) => {
    const count = counter[item.id] || 0;
    const isCompleted = count >= item.count;
    
    return (
      <View 
        style={[
          styles.athkarCard, 
          { backgroundColor: cardColor },
          isCompleted && styles.completedCard
        ]}
      >
        <Text style={[styles.athkarText, { color: textColor, fontSize: getFontSize(18) }]}>{item.text}</Text>
        
        {item.fadl && (
          <Text style={[styles.athkarFadl, { color: textColor, fontSize: getFontSize(14) }]}>
            الفضل: {item.fadl}
          </Text>
        )}
        
        <View style={styles.counterContainer}>
          <Text style={[styles.counterText, { color: textColor }]}>
            {count}/{item.count}
          </Text>
          
          <TouchableOpacity 
            style={[styles.counterButton, isCompleted && styles.disabledButton]}
            onPress={() => dispatch(incrementCounter({ id: item.id, total: item.count }))}
            disabled={isCompleted}
          >
            <Text style={styles.counterButtonText}>تسبيح</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.resetButton}
            onPress={() => dispatch(resetCounter(item.id))}
          >
            <Text style={styles.resetButtonText}>إعادة</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  
  return (
    <View style={[styles.container, { backgroundColor }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: textColor }]}>الأذكار اليومية</Text>
      </View>
      
      <View style={styles.categoryContainer}>
        <TouchableOpacity 
          style={[styles.categoryButton, category === 'morning' && styles.activeCategory]}
          onPress={() => setCategory('morning')}
        >
          <Text style={[styles.categoryText, category === 'morning' && styles.activeCategoryText]}>أذكار الصباح</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.categoryButton, category === 'evening' && styles.activeCategory]}
          onPress={() => setCategory('evening')}
        >
          <Text style={[styles.categoryText, category === 'evening' && styles.activeCategoryText]}>أذكار المساء</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.categoryButton, category === 'other' && styles.activeCategory]}
          onPress={() => setCategory('other')}
        >
          <Text style={[styles.categoryText, category === 'other' && styles.activeCategoryText]}>أذكار متنوعة</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.notificationContainer}>
        <Text style={[styles.notificationText, { color: textColor }]}>تفعيل الإشعارات</Text>
        <Switch 
          value={true} 
          onValueChange={() => {}} 
          trackColor={{ false: '#767577', true: '#4CAF50' }}
          thumbColor={'#f4f3f4'}
        />
      </View>
      
      <FlatList
        data={getCurrentAthkar()}
        keyExtractor={item => item.id.toString()}
        renderItem={renderAthkarItem}
        contentContainerStyle={styles.athkarList}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginVertical: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    textAlign: 'center',
  },
  errorText: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
  },
  retryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  categoryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
    borderRadius: 8,
    overflow: 'hidden',
  },
  categoryButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    backgroundColor: '#e0e0e0',
  },
  activeCategory: {
    backgroundColor: '#4CAF50',
  },
  categoryText: {
    fontSize: 14,
    color: '#000000',
  },
  activeCategoryText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  notificationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  notificationText: {
    fontSize: 16,
  },
  athkarList: {
    paddingBottom: 16,
  },
  athkarCard: {
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  completedCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
  },
  athkarText: {
    textAlign: 'right',
    lineHeight: 28,
    marginBottom: 12,
  },
  athkarFadl: {
    textAlign: 'right',
    fontStyle: 'italic',
    marginBottom: 12,
  },
  counterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  counterText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  counterButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
  },
  disabledButton: {
    backgroundColor: '#a5d6a7',
  },
  counterButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resetButton: {
    backgroundColor: '#f44336',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
  },
  resetButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default AthkarScreen;
