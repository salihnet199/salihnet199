import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { 
  toggleDarkMode, 
  setFontSize, 
  setFontType, 
  toggleNotification,
  setLanguage 
} from '../redux/slices/settingsSlice';

const SettingsScreen = () => {
  const dispatch = useDispatch();
  const { 
    darkMode, 
    fontSize, 
    fontType, 
    notifications, 
    language 
  } = useSelector(state => state.settings);
  
  // تحديد الألوان بناءً على وضع الظلام
  const backgroundColor = darkMode ? '#121212' : '#f5f5f5';
  const textColor = darkMode ? '#ffffff' : '#000000';
  const cardColor = darkMode ? '#1e1e1e' : '#ffffff';
  
  return (
    <ScrollView style={[styles.container, { backgroundColor }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: textColor }]}>الإعدادات</Text>
      </View>
      
      <View style={[styles.section, { backgroundColor: cardColor }]}>
        <Text style={[styles.sectionTitle, { color: textColor }]}>المظهر</Text>
        
        <View style={styles.settingRow}>
          <Text style={[styles.settingLabel, { color: textColor }]}>الوضع الليلي</Text>
          <Switch 
            value={darkMode} 
            onValueChange={() => dispatch(toggleDarkMode())} 
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={'#f4f3f4'}
          />
        </View>
        
        <View style={styles.settingRow}>
          <Text style={[styles.settingLabel, { color: textColor }]}>حجم الخط</Text>
          <View style={styles.fontSizeContainer}>
            <TouchableOpacity 
              style={[
                styles.fontSizeButton, 
                fontSize === 'small' && styles.activeFontSize
              ]}
              onPress={() => dispatch(setFontSize('small'))}
            >
              <Text style={[
                styles.fontSizeText, 
                fontSize === 'small' && styles.activeFontSizeText
              ]}>
                صغير
              </Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[
                styles.fontSizeButton, 
                fontSize === 'medium' && styles.activeFontSize
              ]}
              onPress={() => dispatch(setFontSize('medium'))}
            >
              <Text style={[
                styles.fontSizeText, 
                fontSize === 'medium' && styles.activeFontSizeText
              ]}>
                متوسط
              </Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[
                styles.fontSizeButton, 
                fontSize === 'large' && styles.activeFontSize
              ]}
              onPress={() => dispatch(setFontSize('large'))}
            >
              <Text style={[
                styles.fontSizeText, 
                fontSize === 'large' && styles.activeFontSizeText
              ]}>
                كبير
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.settingRow}>
          <Text style={[styles.settingLabel, { color: textColor }]}>نوع الخط</Text>
          <View style={styles.fontTypeContainer}>
            <TouchableOpacity 
              style={[
                styles.fontTypeButton, 
                fontType === 'default' && styles.activeFontType
              ]}
              onPress={() => dispatch(setFontType('default'))}
            >
              <Text style={[
                styles.fontTypeText, 
                fontType === 'default' && styles.activeFontTypeText
              ]}>
                افتراضي
              </Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[
                styles.fontTypeButton, 
                fontType === 'uthmani' && styles.activeFontType
              ]}
              onPress={() => dispatch(setFontType('uthmani'))}
            >
              <Text style={[
                styles.fontTypeText, 
                fontType === 'uthmani' && styles.activeFontTypeText
              ]}>
                عثماني
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      
      <View style={[styles.section, { backgroundColor: cardColor }]}>
        <Text style={[styles.sectionTitle, { color: textColor }]}>الإشعارات</Text>
        
        <View style={styles.settingRow}>
          <Text style={[styles.settingLabel, { color: textColor }]}>أذكار الصباح</Text>
          <Switch 
            value={notifications.athkarMorning} 
            onValueChange={() => dispatch(toggleNotification('athkarMorning'))} 
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={'#f4f3f4'}
          />
        </View>
        
        <View style={styles.settingRow}>
          <Text style={[styles.settingLabel, { color: textColor }]}>أذكار المساء</Text>
          <Switch 
            value={notifications.athkarEvening} 
            onValueChange={() => dispatch(toggleNotification('athkarEvening'))} 
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={'#f4f3f4'}
          />
        </View>
        
        <View style={styles.settingRow}>
          <Text style={[styles.settingLabel, { color: textColor }]}>آية يومية</Text>
          <Switch 
            value={notifications.dailyVerse} 
            onValueChange={() => dispatch(toggleNotification('dailyVerse'))} 
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={'#f4f3f4'}
          />
        </View>
      </View>
      
      <View style={[styles.section, { backgroundColor: cardColor }]}>
        <Text style={[styles.sectionTitle, { color: textColor }]}>عن التطبيق</Text>
        
        <View style={styles.aboutRow}>
          <Text style={[styles.aboutLabel, { color: textColor }]}>الإصدار</Text>
          <Text style={[styles.aboutValue, { color: textColor }]}>1.0.0</Text>
        </View>
        
        <View style={styles.aboutRow}>
          <Text style={[styles.aboutLabel, { color: textColor }]}>المطور</Text>
          <Text style={[styles.aboutValue, { color: textColor }]}>فريق تطوير التطبيقات الإسلامية</Text>
        </View>
        
        <TouchableOpacity style={styles.feedbackButton}>
          <Text style={styles.feedbackButtonText}>إرسال ملاحظات</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.rateButton}>
          <Text style={styles.rateButtonText}>تقييم التطبيق</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginVertical: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  section: {
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'right',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  settingLabel: {
    fontSize: 16,
  },
  fontSizeContainer: {
    flexDirection: 'row',
  },
  fontSizeButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginHorizontal: 4,
    borderRadius: 4,
    backgroundColor: '#e0e0e0',
  },
  activeFontSize: {
    backgroundColor: '#4CAF50',
  },
  fontSizeText: {
    color: '#000000',
  },
  activeFontSizeText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  fontTypeContainer: {
    flexDirection: 'row',
  },
  fontTypeButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginHorizontal: 4,
    borderRadius: 4,
    backgroundColor: '#e0e0e0',
  },
  activeFontType: {
    backgroundColor: '#4CAF50',
  },
  fontTypeText: {
    color: '#000000',
  },
  activeFontTypeText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  aboutRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  aboutLabel: {
    fontSize: 16,
  },
  aboutValue: {
    fontSize: 16,
  },
  feedbackButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 4,
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 8,
  },
  feedbackButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  rateButton: {
    backgroundColor: '#FFC107',
    paddingVertical: 12,
    borderRadius: 4,
    alignItems: 'center',
  },
  rateButtonText: {
    color: '#000000',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default SettingsScreen;
