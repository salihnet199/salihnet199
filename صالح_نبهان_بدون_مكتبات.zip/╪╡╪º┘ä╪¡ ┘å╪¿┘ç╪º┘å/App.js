/**
 * @file App.js
 * @description نقطة الدخول الرئيسية للتطبيق الإسلامي المتكامل
 * @author فريق تطوير التطبيق الإسلامي
 * @version 1.0.0
 */

import React, { useEffect, useState } from 'react';
import { StatusBar, SafeAreaView, StyleSheet, View } from 'react-native';
import { Provider } from 'react-redux';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/MaterialIcons';

// استيراد المتجر
import store from './src/redux/store';

// استيراد الشاشات
import HomeScreen from './src/screens/HomeScreen';
import QuranScreen from './src/screens/QuranScreen';
import AthkarScreen from './src/screens/AthkarScreen';
import TafseerScreen from './src/screens/TafseerScreen';
import AudioScreen from './src/screens/AudioScreen';
import SettingsScreen from './src/screens/SettingsScreen';

// استيراد الأنماط والألوان
import colors from './src/styles/colors';

// استيراد تحسينات الأداء وواجهة المستخدم
import { optimizeStartup } from './src/utils/performance';
import { uiEnhancements } from './src/utils/ui-enhancements';

// إنشاء مكدس التنقل والتبويب السفلي
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

/**
 * مكون التبويب السفلي للتنقل بين الشاشات الرئيسية
 * @returns {React.Component} مكون التبويب السفلي
 */
const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          // تحديد الأيقونة المناسبة لكل تبويب
          let iconName;
          if (route.name === 'الرئيسية') {
            iconName = 'home';
          } else if (route.name === 'القرآن') {
            iconName = 'book';
          } else if (route.name === 'الأذكار') {
            iconName = 'favorite';
          } else if (route.name === 'التفسير') {
            iconName = 'description';
          } else if (route.name === 'التلاوات') {
            iconName = 'headset';
          } else if (route.name === 'الإعدادات') {
            iconName = 'settings';
          }
          
          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.gray,
        tabBarLabelStyle: {
          fontFamily: 'Cairo-Regular',
          fontSize: 12,
        },
        tabBarStyle: {
          backgroundColor: colors.white,
          borderTopWidth: 1,
          borderTopColor: colors.lightGray,
          height: 60,
          paddingBottom: 5,
          paddingTop: 5,
        },
        headerShown: false,
      })}
    >
      <Tab.Screen name="الرئيسية" component={HomeScreen} />
      <Tab.Screen name="القرآن" component={QuranScreen} />
      <Tab.Screen name="الأذكار" component={AthkarScreen} />
      <Tab.Screen name="التفسير" component={TafseerScreen} />
      <Tab.Screen name="التلاوات" component={AudioScreen} />
      <Tab.Screen name="الإعدادات" component={SettingsScreen} />
    </Tab.Navigator>
  );
};

/**
 * المكون الرئيسي للتطبيق
 * @returns {React.Component} مكون التطبيق الرئيسي
 */
const App = () => {
  // حالة تحميل التطبيق
  const [isLoading, setIsLoading] = useState(true);
  
  // تحسين وقت بدء التشغيل
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // تحسين وقت بدء التشغيل
        optimizeStartup();
        
        // محاكاة وقت التحميل
        setTimeout(() => {
          setIsLoading(false);
        }, 2000);
      } catch (error) {
        console.error('خطأ في تهيئة التطبيق:', error);
        setIsLoading(false);
      }
    };
    
    initializeApp();
  }, []);
  
  // عرض شاشة التحميل
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        {/* يمكن إضافة شعار التطبيق أو مؤشر التحميل هنا */}
      </View>
    );
  }
  
  // عرض التطبيق الرئيسي
  return (
    <Provider store={store}>
      <NavigationContainer>
        <SafeAreaView style={styles.container}>
          <StatusBar
            backgroundColor={colors.primary}
            barStyle="light-content"
          />
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
            }}
          >
            <Stack.Screen name="Main" component={TabNavigator} />
          </Stack.Navigator>
        </SafeAreaView>
      </NavigationContainer>
    </Provider>
  );
};

/**
 * أنماط المكون الرئيسي
 */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.white,
  },
});

export default App;
